<?php

//include "../connection.php";
$q = explode("@-",$_REQUEST["q"]);

   $from_date = date_create($q[1]);
   $from_date1 = date_create($q[2]);
  $to_date = date_create($q[0]);


 $ndays = 0;
 $diff = date_diff($from_date,$to_date);
 $diff1 = date_diff($from_date1,$to_date);

 
   $years = $diff->format('%y'); 
   $months = $diff->format('%m'); 
   $days = $diff->format('%d'); 
   
    $years1 = $diff1->format('%y'); 
   $months1 = $diff1->format('%m'); 
   $days1 = $diff1->format('%d'); 
   
$month1 = $years*12;

if($days1 == 0 ){
	$month2 = $years*12+$months1;
}
else{
if($days1 > 15){
$month2 = $years*12+$months1+1;
}

else{
	$month2 = $years*12+$months1+0.5;
}
}
echo $years.' Years '.$months.' Month '.$days.' Days '.'@-'.$years.'@-'.$months.'@-'.$days1.'@-'.$month2.'@-'.$years1.'@-'.$months1;



