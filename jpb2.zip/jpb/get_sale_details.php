<?php

include "connection.php";

$q = $_REQUEST["q"];
$pres = 'n';

 
  $sql2 = "SELECT * FROM `i_sale_products` where bill_no = '".$q."' ";
  $result2= mysqli_query($con,$sql2);
  if($result2){
	 $pres = '';
	$row2 = mysqli_fetch_assoc($result2); 
	 $sql3 = "SELECT * FROM `i_sale_products` where bill_no = '".$row2['bill_no']."'";
 $result3= mysqli_query($con,$sql3);
 $ct =mysqli_num_rows($result3);
 $j=0;
 while($row3 = mysqli_fetch_assoc($result3)){$j++;
	 if($j>1)
	 $pres .= '#-#';
 $pres .= $row3['item_name'].'@-@'.$row3['qty'].'@-@'.$row3['price'].'@-@'.$row3['dis_per'].'@-@'.$row3['dis_amt'].'@-@'.$row3['tax_per'].'@-@'.$row3['tax_amt'].'@-@'.$row3['bill_amount'];
	 
				}
 }
 


if($ct<1)
	 echo $q.'#--#n';
	 else if($ct>0)

 echo $q.'#--#'.$pres;
 else '';