<?php

include "connection.php";

 $sid = $_GET['id'];

 
 	$sql = "Delete FROM vendors where id = '$sid'";
	$result= mysqli_query($con,$sql);
	
	$url ="add_vendor.php";
	redirect($url);
?>