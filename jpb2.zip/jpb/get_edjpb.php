<?php 
include'connection.php';
$q = $_REQUEST["q"];


 $sql = "SELECT * FROM `amount` where slip_no = '".$q."'  ";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);

$sql_i = "SELECT * FROM `intrest` where slip_no = '".$q."' ";
$result_i = mysqli_query($con,$sql_i);
$row_i = mysqli_fetch_assoc($result_i);

	$dt1 = explode("-",$row['p_date']);
	 $date = $dt1[2].'-'.$dt1[1].'-'.$dt1[0];

	 
	 	$dt2 = explode("-",$row_i['i_date']);
	 $date1 = $dt2[2].'-'.$dt2[1].'-'.$dt2[0];
	 
	 
	   $t_date = date('Y-m-d');
	   $from_date = date_create($row_i['i_date']);
	   $from_date1 = date_create($row['p_date']);
	   $to_date = date_create(date('Y-m-d'));


 $ndays = 0;
 $diff = date_diff($from_date,$to_date);
 $diff1 = date_diff($from_date1,$to_date);

 
   $years = $diff->format('%y'); 
   $months = $diff->format('%m'); 
   $days = $diff->format('%d'); 
 
   $years1 = $diff1->format('%y'); 
   $months1 = $diff1->format('%m'); 
   $days1 = $diff1->format('%d'); 
   
   $amount = $row_i['amount'];
   $i_amount = ($amount*$row['interst'])/100;
   
$month1 = $years*12;
$month2 = $years*12+$months;

if($month2 >= 12){
	$dt1 = explode("-",$row_i['i_date']);
	 $n_date = ($dt1[0]+1).'-'.($dt1[1]).'-'.($dt1[2]);
	$n_iamount = $i_amount*12;
	$new_amount = $row_i['amount']+$n_iamount;
	
	$sql_u = "UPDATE `intrest` SET amount = '$new_amount',i_date = '$n_date' where slip_no = '".$q."'";
	mysqli_query($con,$sql_u);
}

 $o_int = $i_amount*$month2;

$t_amount = $o_int+$row_i['amount'];

echo $q.'@-$'.$date.'@-$'.$row['name'].'@-$'.$row['interst'].'@-$'.$row['weight'].'@-$'.$month2.'@-$'.$days.'@-$'.$amount.'@-$'.$i_amount.'@-$'.$o_int.'@-$'.$t_amount.'@-$'.$row['i_details'].'@-$'.$t_date.'@-$'.$row['amount'].'@-$'.$date1.'@-$'.$years1.'@-$'.$months1;

?>