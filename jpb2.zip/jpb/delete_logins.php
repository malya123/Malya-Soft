<?php

include "connection.php";

 $sid = $_GET['id'];

 
 	$sql = "Delete FROM users where id = '$sid'";
	$result= mysqli_query($con,$sql);
	
	$url ="add_logins.php";
	redirect($url);
?>