<!DOCTYPE html>
	<html>
	<?php
	include "connection.php";
	//include 'session_check.php';	
	?>
   
	<body>

	<?php 

	
$sql = "SELECT * from i_sale where `bill_no` = '".$_GET['id']."' ";
$result= mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$bill_id = $row['id'];
$bill_amt = $row['bill_amt'];
$bill_dis = $row['bill_dis_rs'];
$advance = $row['advance'];
$balance = $row['balance'];
$customer_name = $row['customer_name'];



?>

<?php


$lineHeaderCharLength = 48;
$lineItemCharLength = 26;
$lineQtyCharLength = 5;
$linePriceCharLength = 6;
$lineAmouontCharLength = 8;
$lineSummaryCharLength = 37;
$lineTypeCharLength = 7;
$lineAmouontCharLengths = 10;

$data = array();
// printer header start

		
//$data[] = str_pad("", $lineHeaderCharLength,"=",STR_PAD_RIGHT);
$data[] = str_pad("BASIL ORGANICS", $lineHeaderCharLength," ",STR_PAD_BOTH);
$data[] = str_pad("Cell: 9703199699", $lineHeaderCharLength," ",STR_PAD_BOTH);
$data[] = str_pad("OPP: SRK School , MaguntaLayout , Nellore.", $lineHeaderCharLength," ",STR_PAD_BOTH);
$data[] = str_pad("GST NO: 37AYUPS2291R1Z3", $lineHeaderCharLength," ",STR_PAD_BOTH);
$data[] = str_pad("", $lineHeaderCharLength,"=",STR_PAD_RIGHT);
$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);

// printer header end.
 ?>
 
 
 
 <?php
 
$timezone = 'Asia/kolkata';
date_default_timezone_set($timezone);

   $time_now = "".date('h:i:s');

							 // printer sub heading printing start
//$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);

if(!empty($customer_name)) {
	$data[] = str_pad("Customer Name", 15 ," ",STR_PAD_RIGHT).": ".$customer_name;
}



$data[] = str_pad("Bill No:", 15 ," ",STR_PAD_RIGHT).": ".$row['bill_no'];
$data[] = str_pad("Date:", 15 ," ",STR_PAD_RIGHT).": ".decode_date($row['date']);
$data[] = str_pad("Time:", 15 ," ",STR_PAD_RIGHT).": ".$time_now;

$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);
$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);
$data[] = str_pad("Item Name", $lineItemCharLength," ",STR_PAD_RIGHT).
            str_pad("Qty", $lineQtyCharLength," ",STR_PAD_LEFT).
			str_pad("Price", $lineTypeCharLength," ",STR_PAD_LEFT).
            str_pad("Amount", $lineAmouontCharLength," ",STR_PAD_LEFT);
$data[] = str_pad("", $lineHeaderCharLength,"=",STR_PAD_RIGHT);




// printer sub heading ends here
?>


<?php 

$i = 0;
	
	$item_name = '';
	
	$sql_2 = "SELECT * from i_sale_products where `sid` = $bill_id";
	$result_2= mysqli_query($con,$sql_2);
	while($row_2 = mysqli_fetch_assoc($result_2)){
	
	
//	$parts = explode('-',$row_2['item_des']);
    //$item_name = $parts[0];


	    $price = round($row_2['bill_amount'] / $row_2['qty'], 2, PHP_ROUND_HALF_DOWN);

	
	
			// printer kot data start


		$data[] = str_pad($row_2['short'], $lineItemCharLength," ",STR_PAD_RIGHT).str_pad($row_2['qty'], $lineQtyCharLength," ",STR_PAD_LEFT).str_pad($price, $lineTypeCharLength," ",STR_PAD_LEFT).str_pad($row_2['bill_amount'], $lineAmouontCharLength," ",STR_PAD_LEFT);
		//$data[] = str_pad("", 10 ," ",STR_PAD_RIGHT).": ".($row_2['item_code']);

	}
			//printer data print ends
			?>
			
	


		<?php 
		//printer summaru data 
		
		$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);
		$data[] = str_pad("", $lineHeaderCharLength,"-",STR_PAD_RIGHT);
		$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);
		$data[] = str_pad("Bill Amount (Incl. Tax):", $lineSummaryCharLength," ",STR_PAD_LEFT).str_pad($row['bill_amt'], $lineAmouontCharLength," ",STR_PAD_LEFT);
		
		$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);

		//$data[] = str_pad("Tax Amount:", $lineSummaryCharLength," ",STR_PAD_LEFT).str_pad($row['cgst_amount'] + $row['sgst_amount'], $lineAmouontCharLength," ",STR_PAD_LEFT);
		//$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);
		
		if($row['bill_dis_rs'] > 0) {
			
		$data[] = str_pad("Discount:", $lineSummaryCharLength," ",STR_PAD_LEFT).str_pad($row['bill_dis_rs'], $lineAmouontCharLength," ",STR_PAD_LEFT);
		$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);
		$data[] = str_pad("", $lineHeaderCharLength,"-",STR_PAD_RIGHT);
		$data[] = str_pad("Total Rs:", $lineSummaryCharLength," ",STR_PAD_LEFT).str_pad($row['bill_amt'] - $row['bill_dis_rs'], $lineAmouontCharLength," ",STR_PAD_LEFT);
		$data[] = str_pad("", $lineHeaderCharLength,"-",STR_PAD_RIGHT);
		
		}
		
		else {
			'';
		}
		
		
		$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);
		$data[] = str_pad("Payment Mode:", $lineAmouontCharLengths," ",STR_PAD_RIGHT).str_pad($row['invoice_type'], $lineAmouontCharLength," ",STR_PAD_LEFT);
		$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);

		
		// printer summary end
		
		?>




		
	

						<?php 
							// printing last text start
							$data[] = str_pad("", $lineHeaderCharLength,"=",STR_PAD_RIGHT);

							$data[] = str_pad("* THANKING YOU, VISIT AGAIN *", $lineSummaryCharLength," ",STR_PAD_LEFT);
							$data[] = str_pad("", $lineHeaderCharLength," ",STR_PAD_RIGHT);
							// printing last text ends
							?>	


<?php 
	
	//printing kot
	require_once 'printer/usbprint.php';
	
	printFromTEXT($data);
	
	
	$url = "sale.php";
	redirect($url);


	?>
</body>
	</html>