<!DOCTYPE html>
<html>

<?php include 'connection.php'; ?>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>PRINCE JEWELLERY</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			
			
			

	
	<?php

	
if(isset($_POST["update"])){

 $productname = $_POST['productname'];


echo $sql = "UPDATE  `product` SET `productname` = '".$productname."'  where id = '".$_GET['id']."' ";
	
	$result= mysqli_query($con,$sql);

 $url = 'addproduct.php';
 redirect($url);

}
?>


			<!-- Page Title -->
			
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			<!-- Main Content -->
			
			
				
			<?php 
			
									$sql = "SELECT * FROM `product` where id = '".$_GET['id']."' ";
									$result = mysqli_query($con , $sql);
									$row = mysqli_fetch_assoc($result);
										
			
			?>
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">ADDPRODUCT</h3>
							<form method = "post">
								<div class="form-row">
								<div class="form-group col-md-3">
										<label for="patient-name">Product Name</label>
										<input type="text" class="form-control"  name="productname" id="productname" value="<?php echo $row['productname']; ?>" required >
									
									</div>
									<div class="form-group col-md-3" style="display:none">
										<label for="patient-name">Address</label>
										<input type="text" class="form-control" value="" name="adress" id="adress"  >
									</div>
								
									<div class="form-group col-md-3" style="display:none">
										<label for="dob">PHONE</label>
										<input type="text" class="form-control" value="" name="phone" id="phone"  >
									</div>
										
									<div class="form-group col-md-6 mb-3" style="margin-top:30px">
										<button type="submit" name="update" class="btn btn-primary btn-lg">update</button>
									</div>
								</div>
							</form>
								
						</div>
					</div>
					
					<!-- /Widget Item -->
				</div>
			
			</div>
			<!-- /Main Content -->
			
			
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>

</body>

</html>
