<?php
session_start();

$servername = "localhost";
$database = "pawn";
$username = "root";
$password = "";

$con= mysqli_connect($servername,$username,$password,$database); 
if(!$con){
	echo "could not connect".mysqli_connect_error();
}
else{

}
function redirect($url)
{
    if (!headers_sent())
    {    
        header('Location: '.$url);
        exit;
        }
    else
        {  
        echo '<script type="text/javascript">';
        echo 'window.location.href="'.$url.'";';
        echo '</script>';
        echo '<noscript>';
        echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
        echo '</noscript>'; exit;
    }
}


function decode_date($date){

	
		$pts = explode("-",$date);
		
		$res = $pts[2].'-'.$pts[1].'-'.$pts[0];
		return $res;
		
	}
	
?>