<!DOCTYPE html>
	<html>
	 <style>
    .invoice-box {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }
    
    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }
    
    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
    }
    
    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }
    
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    
    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }
    
    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }
    
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom: 1px solid #eee;
    }
    
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    
    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }
        
        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
 .bill tr td {
	  border-top: 2px solid #eee
 }
    
    /** RTL **/
    .rtl {
        direction: rtl;
        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    }
    
    .rtl table {
        text-align: right;
    }
    
    .rtl table tr td:nth-child(2) {
        text-align: left;
    }
    </style>
	<?php
	include "commonhead.php";
		
	
$table = $_POST['table'];

	
	$items_price = $_POST['items'];
	 
	
	$i= 0;
	$amount = 0;
	$items = '';
		 foreach ($items_price as $val) {
		if($i>0)
	 $items .= ', ';
		$item = explode("-",$val);
		$amount += $item[1];
		$items .= $item[0].'-'.$item[2];
		$i++;
		 }
	
	
	$sql = "INSERT INTO `order` (`table`, `items`, `amount`, `status`) VALUES ('".$table."', '".$items."', '".$amount."','p')";
	$result= $db->query($sql);	
	
		
			$sql = "INSERT INTO `bill` (`table`, `items`, `bill`, `date`) VALUES ('".$table."', '".$items."', 'n', '".date('Y-m-d')."')";
	$result= $db->query($sql);
$lid = $db->lastInsertRowId();
 
	 ?>
	 
	 
	

	<body>

	
	
	<!-- Header -->

<div class= "w3-heads">

	<header class="w3-container" style="background-color: #f2d7d5;" >

	<div class="panel-heading"  style="background-color:  #8e44ad;">
			
		<h3>Print Parcel Bill</h3>
		</div>

	
	<div class="panel panel-default w3-row">
	
	
		 <?php
		$table = $_POST['table'];
		$total_amount = 0;
		$sql = "SELECT * from bill where `id` = $lid";
	
	$result= $db->query($sql);
	$row = $result->fetchArray(SQLITE3_ASSOC);
	$item_price = explode(',',$row['items']);
	?>
	<input type="button" onclick="printDiv('printableArea')" value="print" />
	 <div class="invoice-box" id="printableArea">
       
                   
							<div style="line-height: 10px;font-size:2em;clear: both;text-align: center;">
                                <p style="line-height: 20px;font-size:1.5em;">SHAHRUKH RESTAURANT<br><small style="font-size: 0.3em;">M  u  l  t  i    C  u  i  s  i  n  e</small></p>
								
								<p style="margin-top: -30px;">Chandra Mouli Nagar, vedaya palem,</p>
								<p>Nellore - 524004.</p>
								<p style="line-height: 10px;">Cell: 8309091027, 8074831623 </p>
								<p>GST NO:</P>
								<p>INVOICE</p>
								</div>
								
                            
							<div style = "font-size: 2em;width:35%;float: left;">Bill No.<?php echo $row['id']; ?></div><div style = "font-size: 2em;width:30%;text-align: center;float: left;">Table No.<?php echo $row['table']; ?></div><div style="font-size: 2em;">Date: 
							<span id="date"></span></div>
							<BR>
							<div style="width:100%">
						<table  class ="bill" style="width:100%" >
							<tr>
							<td style = "font-size: 1.4em;text-decoration: bold;width:45%;text-align: center;float: left;">Items</td><td style = "font-size: 1.4em;text-decoration: bold;width:10%;text-align: right;float: left;">Qty</td><td style = "font-size: 1.4em;text-decoration: bold;width:16%;text-align: right;float: left;">Rate</td><td style = "font-size: 1.2em;text-decoration: bold;width:29%;text-align: right;float: left;">Gross</td>
							</tr>
							
							<?php
							$i=1;
							$taxsql = "SELECT * from tax";
		$taxresult= $db->query($taxsql);
		$taxrow = $taxresult->fetchArray(SQLITE3_ASSOC);
		
							foreach($item_price as $val){
					$items = explode('-',$val);
				$item = trim($items[0]);
		$sql1 = "SELECT price from products where `pname` = '$item'";
		$result1= $db->query($sql1);
		$row1 = $result1->fetchArray(SQLITE3_ASSOC);
	$unit_price = $row1['price'];
		 $qty = $items[1];
		$total_price = $qty*$unit_price;
							echo '<tr><td style = "font-size: 1.2em;text-decoration: bold;width:45%;float: left;" nowrap="nowrap">'.$item.'</td><td style = "font-size: 1.2em;text-decoration: bold;width:10%;text-align: right;float: left;">'.$qty.'</td><td style = "font-size: 1.2em;text-decoration: bold;width:16%;text-align: right;float: left;"><i class="fa fa-inr"></i> '.$unit_price.'</td><td style = "font-size: 1.2em;text-decoration: bold;width:29%;text-align: right;float: left;"><i class="fa fa-inr"></i> '.$total_price.'</td></tr>'; 							
							$total_amount += $total_price;
							$i++;
	}
	
		$cgst = $taxrow['cgst']*$total_amount/100;
		$sgst = $taxrow['sgst']*$total_amount/100;
		$service = $taxrow['service']*$total_amount/100;
		$net = $total_amount+$cgst+$sgst+$service;
		
		echo ' <tr><td style = "width:60%;float: left;font-size: 1.2em;text-decoration: bold;text-align: right;">Total:</td><td style="font-size: 1.2em;text-decoration: bold;width:31%;float: right;text-align: right;"><i class="fa fa-inr"></i> '.$total_amount.'</td></tr>';
		echo '<tr><td style = "width:60%;float: left;font-size: 1.2em;text-decoration: bold;text-align: right;">CGST'.$taxrow['cgst'].'%:</td><td style="font-size: 1.2em;text-decoration: bold;width:31%;float: right;text-align: right;"><i class="fa fa-inr"></i> '.$cgst.'</td></tr>';
		echo '<tr><td style = "width:60%;float: left;font-size: 1.2em;text-decoration: bold;text-align: right;">SGST'.$taxrow['sgst'].'%:</td><td style="font-size: 1.2em;text-decoration: bold;width:31%;float: right;text-align: right;"><i class="fa fa-inr"></i> '.$sgst.'</td></tr>';
		echo '<tr><td style = "width:60%;float: left;font-size: 1.2em;text-decoration: bold;text-align: right;">Serv. Tax'.$taxrow['service'].'%:</td><td style="font-size: 1.2em;text-decoration: bold;width:31%;float: right;text-align: right;"><i class="fa fa-inr"></i> '.$service.'</td></tr>';
		echo '<tr><td style = "width:60%;font-size: 1.2em;text-decoration: bold;float: left;text-align: right;">Net Amount:</td><td style="font-size: 1.2em;text-decoration: bold;width:31%;float: right;text-align: right;"><i class="fa fa-inr" ></i> '.$net.'</td></tr>';
		echo '</table>';
		
		
			$sql = "UPDATE `bill` SET  `bill` = 'y', `amount` = '$total_amount' WHERE `id` = '$lid'";
	$result= $db->query($sql);				
							?>
							
										
							
							 
							
							<hr>
							<div id="container" style="font-size: 1.4em;text-decoration: bold;"></div>
							<div style="font-size: 1.2em;text-decoration: bold;">PLEASE CHECK YOUR BILL BEFORE PAYING</div>
							<div style="text-align: right;font-size: 1.4em;text-decoration: bold;">Signature</div>
								
							
							   
    </div>
	
	
	


	
	</div>

									   
	<div class="panel-footer" >

	

	</div><!-- panel-footer -->
	<!-- panel-default -->

	</div>
	</div>
	</header>
	</div>
	<!-- First Grid -->

<script>
	n =  new Date();
y = n.getFullYear();
m = n.getMonth() + 1;
d = n.getDate();
document.getElementById("date").innerHTML = d + "/" + m + "/" + y;


function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
//-----Amount Convert to Words---------
var iWords = ['Zero', ' One', ' Two', ' Three', ' Four', ' Five', ' Six', ' Seven', ' Eight', ' Nine'];
var ePlace = ['Ten', ' Eleven', ' Twelve', ' Thirteen', ' Fourteen', ' Fifteen', ' Sixteen', ' Seventeen', ' Eighteen', ' Nineteen'];
var tensPlace = ['', ' Ten', ' Twenty', ' Thirty', ' Forty', ' Fifty', ' Sixty', ' Seventy', ' Eighty', ' Ninety'];
var inWords = [];
 
var numReversed, inWords, actnumber, i, j;
 
function tensComplication() {
    
    if (actnumber[i] === 0) {
        inWords[j] = '';
    } else if (actnumber[i] === 1) {
        inWords[j] = ePlace[actnumber[i - 1]];
    } else {
        inWords[j] = tensPlace[actnumber[i]];
    }
}
 
function testSkill() {
    
    var junkVal = <?php echo $net; ?>;
	
    junkVal = Math.floor(junkVal);
    var obStr = junkVal.toString();
    numReversed = obStr.split('');
    actnumber = numReversed.reverse();
 
    if (Number(junkVal) >= 0) {
        //do nothing
    } else {
        window.alert('wrong Number cannot be converted');
        return false;
    }
    if (Number(junkVal) === 0) {
        document.getElementById('container').innerHTML = obStr + '' + 'Rupees Zero Only';
        return false;
    }
    if (actnumber.length > 9) {
        window.alert('Oops!!!! the Number is too big to covertes');
        return false;
    }
 
 
 
    var iWordsLength = numReversed.length;
    var finalWord = '';
    j = 0;
    for (i = 0; i < iWordsLength; i++) {
        switch (i) {
            case 0:
                if (actnumber[i] === '0' || actnumber[i + 1] === '1') {
                    inWords[j] = '';
                } else {
                    inWords[j] = iWords[actnumber[i]];
                }
                inWords[j] = inWords[j] + ' Rupees Only';
                break;
            case 1:
                tensComplication();
                break;
            case 2:
                if (actnumber[i] === '0') {
                    inWords[j] = '';
                } else if (actnumber[i - 1] !== '0' && actnumber[i - 2] !== '0') {
                    inWords[j] = iWords[actnumber[i]] + ' Hundred and';
                } else {
                    inWords[j] = iWords[actnumber[i]] + ' Hundred';
                }
                break;
            case 3:
                if (actnumber[i] === '0' || actnumber[i + 1] === '1') {
                    inWords[j] = '';
                } else {
                    inWords[j] = iWords[actnumber[i]];
                }
                if (actnumber[i + 1] !== '0' || actnumber[i] > '0') {
                    inWords[j] = inWords[j] + ' Thousand';
                }
                break;
            case 4:
                tensComplication();
                break;
            case 5:
                if (actnumber[i] === '0' || actnumber[i + 1] === '1') {
                    inWords[j] = '';
                } else {
                    inWords[j] = iWords[actnumber[i]];
                }
                if (actnumber[i + 1] !== '0' || actnumber[i] > '0') {
                    inWords[j] = inWords[j] + ' Lakh';
                }
                break;
            case 6:
                tensComplication();
                break;
            case 7:
                if (actnumber[i] === '0' || actnumber[i + 1] === '1') {
                    inWords[j] = '';
                } else {
                    inWords[j] = iWords[actnumber[i]];
                }
                inWords[j] = inWords[j] + ' Crore';
                break;
            case 8:
                tensComplication();
                break;
            default:
                break;
        }
        j++;
    }
 
 
    inWords.reverse();
    for (i = 0; i < inWords.length; i++) {
        finalWord += inWords[i];
    }
    document.getElementById('container').innerHTML = finalWord;
}
testSkill();
</script>

	</body>
	</html>