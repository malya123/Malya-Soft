<?php
require __DIR__ . '/vendor/autoload.php';

use Mike42\Escpos\PrintConnectors\NetworkPrintConnector;
use Mike42\Escpos\ImagickEscposImage;
use Mike42\Escpos\Printer;





function printFromHTML($source){
	$ip = "192.168.0.50";
        $port = 9100;
        
	
	$connector = new NetworkPrintConnector($ip, $port);
        $printer = new Printer($connector);
   try {
        
        
        echo $dest = tempnam(sys_get_temp_dir(), 'escpos') . ".pdf";
        
        $command = sprintf(
            "wkhtmltopdf -n -q  %s %s",
            escapeshellarg($source),
            escapeshellarg($dest)
            );
        
        /* Test for dependencies */
        foreach (array("wkhtmltopdf") as $cmd) {
            $testCmd = sprintf("which %s", escapeshellarg($cmd));
            exec($testCmd, $testOut, $testStatus);
            if ($testStatus != 0) {
               // throw new Exception("You require $cmd but it could not be found");
            }
        }
        
        
        /* Run wkhtmltoimage */
        $descriptors = array(
            1 => array("pipe", "w"),
            2 => array("pipe", "w"),
        );
        $process = proc_open($command, $descriptors, $fd);
        
        
        
        if (is_resource($process)) {
            /* Read stdout */
            $outputStr = stream_get_contents($fd[1]);
            fclose($fd[1]);
            /* Read stderr */
            $errorStr = stream_get_contents($fd[2]);
            fclose($fd[2]);
            /* Finish up */
            $retval = proc_close($process);
            /*if ($retval != 0) {
                throw new Exception("Command $cmd failed: $outputStr .' || '.$errorStr");
            }*/
        } else {
            throw new Exception("Command '$cmd' failed to start.");
        }
        
        /* Load up the image */
        try {
            $pages = ImagickEscposImage::loadPdf($dest);
        } catch (Exception $e) {
            unlink($dest);
            throw $e;
        }
        
        
        
        
        /* Print it */
        foreach ($pages as $page) {
            $printer -> graphics($page);
        }
        unlink($dest);
        $printer -> cut();
    } catch (Exception $e) {
        echo $e -> getMessage();
    } finally {
        $printer -> close();
    }
}





