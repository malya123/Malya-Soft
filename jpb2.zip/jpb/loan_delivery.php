<!DOCTYPE html>
<html>
<?php include 'connection.php' ;?>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>PRINCE JEWELLERY</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
	
	
	
<script src="js1/jquery.min.js"></script>
<script src="js1/select2.full.min.js"></script>
<script src="js1/jquery.inputmask.bundle.min.js"></script>


	
	<style>
	
	a.btn.btn-primary.m-b-5.m-r-2 {
    float: right;
	margin-top: 1.7%;
	}

td.span3.manufacturer {
    padding: 0.5% 0.2% !important;
}

input.form-control {
    padding: .5% .75% !important;
    height: 35px !important;
}
.table-bordered td, .table-bordered th {
    border: 0px solid #dee2e6!important;
}

th.text-center {
    font-size: 12px !important;
}

th.text-center {
    background-color: green;
    color: #fff;
}

.widget-area-2 {
    margin-top: 3px !important;
}

div#lists {
    height: 225px;
    border: 1px solid #ddd;
    width: 104%;
    overflow: auto;
    padding: 0px !important;
    margin: 1% -2%;
}


table#order {
    width: 100%;
}
thead#order_h {
    border: 1px solid #ddd;
}

td.bor {
    border: 1px solid #ddd;
}

button.btn.btn-primary.btn-lg {
	
    background-color: #dc6c97 !important;
}

.form-group.col-md-2 {
    margin-bottom: 0% !important;
}

input.btn.btn-primary.btn-sm {
    width: 50%;
    margin-top: 18%;
    margin-left: 20%;
}

i.ti-close {
    font-size: 13px;
    font-weight: bold;
}

select#invoice_type {
    height: 30px !important;
    padding: 1px 10px;
}

select#expenses_category {
    height: 35px;
}

select#pay_type {
    height: 35px;
}

table.table tbody td, table.table thead th {
    font-size: 14px;
    border: 1px solid #ddd !important;
}

button.btn.btn-primary.btn-lg {
    margin-top: 5.4%;
    margin-left: 10%;
}

i.ti-eye , i.ti-close {
    font-size: 22px;
    padding: 3% 3%;
    background: #e57498;
    color: #fff;
}

th, td {
    padding: 0.5% 0% !important;
    text-align: center;
}

.btn {
    display: inline-block;
    font-weight: 400;
   
    text-align: center;
    vertical-align: middle;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    
    border: 1px solid transparent;
    padding: 0px 5px;
    font-size: 1rem;
    line-height: 0.5;
    border-radius: .25rem;
    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}
.right_side {
    width: 50%;
    border: 1px solid;
    padding: 2% 0%;
	float: left;
	height: 554px;
}
.total {
    width: 100%;
}
.right_side1 {
    border: 1px solid;
    width: 50%;
    float: right;
}
ul.stats-overview li {
    display: inline-block;
    text-align: center;
    padding: 0 15px;
    width: 44%;
    font-size: 14px;
    border-right: 1px solid #e8e8e8;
}
input.nulli {
    border: none;
    text-align: center;
    font-weight: bold;
    color: green;
	outline:none;
}
/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 0px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 90%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  margin-left: 99%;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
	</style>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			<!-- Page Title -->
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Search Invoice</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
                        <li class="breadcrumb-item">Delivery</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
						
							<h3 class="widget-title">Delivery</h3>
			
							
								<div class="form-row">
									
									
									
									<div class="form-group col-md-3">
										<label for="dob">Slip No</label>
	<input type="text" class="form-control" name="slip_no" id="slip_no" >

									</div>
									
									
									

									
									
								</div>
								
							
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			
			

<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <center><h3>DELIVERY BILL VIEW</h3></center>
	
	<div class="total">
	<div class="right_side">
	<ul class="stats-overview">
<li>
<span class="name">SLIP NO</span>
<span class="value text-success"><input value="" class="nulli" id="dslp" readonly></span>
</li>
<li>
<span class="name">DATE</span>
<span class="value text-success"><input value="" id="d_date" class="nulli" readonly></span><input value="" id="d_date1" class="nulli" readonly hidden></span>
</li>


</ul>
<ul class="stats-overview">
<li >
<span class="name">NAME </span>
<span class="value text-success"><input value="" class="nulli" name="ddname" id="ddname" readonly></span>
</li>


<li>
<span class="name">PRINCIPLE AMOUNT </span>
<span class="value text-success"><input value="" id="damount" class="nulli" readonly></span>
</li>



</ul>
<ul class="stats-overview">
<li>
<span class="name">INTERST </span>
<span class="value text-success"><input value="" id="dint" class="nulli" readonly></span>
</li>

<li>
<span class="name">INTERST / MONTH </span>
<span class="value text-success"><input value="" class="nulli" id="m_interst" readonly style="text-align: inherit;"><input value="" class="nulli" id="a_interst" readonly style="text-align: inherit;" hidden></span>
</li>
</ul>
<ul class="stats-overview">
<li>
<span class="name">WEIGHT </span>
<span class="value text-success"><input value="" id="dweight" class="nulli" readonly></span>
</li>
<li>
<span class="name">ITEM DETAILS </span>
<span class="value text-success"><textarea  class="form-control" id="didetails" rows="4" ></textarea></span>
</li>


</ul>
</div>
<div class="right_side1">
<table>
<tbody>
<tr style="line-height: 25px;">
<td style="width: 10%;"></td>
<td  style="text-align: left;">TAKEN DATE</td>

<td style="text-align: left;"> <input value="" id="dt_date" class="nulli" readonly></td>
</tr>
<tr style="line-height: 25px;">
<td></td>
<td  style="text-align: left;">Year MONTHS AND DAYS</td>

<td style="text-align: left;"> <input  class="nulli" value="" id="d_year" readonly style="width: 10%;">YEAR<input  class="nulli" value="" id="d_month" readonly style="width: 10%;"> MONTHS <input  class="nulli" value="" readonly style="width: 10%;" id="d_days"> DAYS</td>
</tr>
<tr style="line-height: 25px;">
<td></td>
<td  style="text-align: left;">DELIVERY DATE</td>

<td style="text-align: left;"> <input id="delivery_date" class="date-picker form-control" placeholder="dd-mm-yyyy" type="date" required="required"  value="" onchange="pdate()" style="width:40%;"></td>
</tr>
<tr style="line-height: 25px;">
<td></td>
<td  style="text-align: left;">&nbsp;</td>

<td style="text-align: left;" colspan="2"> <input type="text" class="nulli1" value="" id="t_month" style="width:40%;"></td>
</tr>
<tr style="line-height: 25px;">
<td></td>
<td style="text-align: left;"> AMOUNT </td>
<td style="text-align: left;"> <input value="" class="nulli" id="p_amount" readonly style="text-align: inherit;"></td>
</tr>

<tr style="line-height: 25px;">
<td></td>
<td style="text-align: left;">INTERST OCCURED </td>
<td style="text-align: left;"> <input id="o_interst" value=""class="nulli" readonly style="text-align: inherit;"></td>
</tr>
<tr style="line-height: 25px;">
<td></td>
<td style="text-align: left;">TOTAL AMOUNT </td>
<td style="text-align: left;"> <input id="t_amount" value="" class="nulli" readonly style="text-align: inherit;"></td>
</tr>
<tr style="line-height: 25px;">
<td></td>
<td style="text-align: left;">DISCOUNT </td>
<td style="text-align: left;" > <input type="text" class="nulli1" value="" id="dis" style="width: 40%;"></td>
</tr>

<tr>

<td></td>

<td style="text-align: left;"> NET AMOUNT </td>
<td style="text-align: left;"> <input type="text" class="nulli" value="" id="n_amount" style="text-align: inherit;" readonly></td>
</tr>


<tr>

<td></td>

<td style="text-align: left;"> Extra Amount </td>
<td style="text-align: left;"> <input type="text" class="" value="" id="extra_amount" style="text-align: inherit;" ></td>
</tr>
<tr>

<td></td>

<td style="text-align: left;"> Jama Amount </td>
<td style="text-align: left;"> <input type="text" class="" value="" id="jama_amount" style="text-align: inherit;" ></td>
</tr>
<tr style="height: 41px;">
</tr>
</tbody>
</table>
</div>
</div>
<div class="ln_solid"></div>
<div class="col-md-6 col-sm-6 offset-md-3">
<center><button class="btn btn-primary" type="button" onclick="save_delivery()" style="padding: 10px 10px;">SAVE</button> <button class="btn btn-primary"  type="button" onclick="save_extra()" style="padding: 10px 10px;background: blueviolet;">Save Extra</button>  <button class="btn btn-primary"  type="button" onclick="save_jama()" style="padding: 10px 10px;background: blue;">Save Jama</button></center>
  </div>
  </div>

</div>

		
			
			
			
			
			<!-- /Main Content -->
			
			
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<!-- <script src="js/jquery-3.2.1.min.js"></script> -->
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>



<script>
$('#dis').keyup(function (e){
	t_amount = document.getElementById("t_amount").value;
	dis = document.getElementById("dis").value;
	n_amount = t_amount-dis;
	document.getElementById("n_amount").value = n_amount.toFixed(2);
});

function pdate() {
	ap_y = document.getElementById("d_date1").value;
	ap_y1 = document.getElementById("d_date").value;
var	ap_m = document.getElementById("delivery_date").value+"@-"+ap_y+"@-"+ap_y1;




        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                   res = this.responseText;
                var str = res.split("@-");
               document.getElementById("d_year").value = str[5]; 
               document.getElementById("d_month").value = str[6]; 
               document.getElementById("d_days").value = str[3]; 
              t_month =  document.getElementById("t_month").value = str[4]; 
               //document.getElementById("pd").value = str[3]; 
			   m_interst = document.getElementById("m_interst").value;
			   a_interst = document.getElementById("a_interst").value;
	

			   o_interst = ((t_month*m_interst)-a_interst);
	 document.getElementById("o_interst").value = o_interst.toFixed(0);
	 p_amount = document.getElementById("p_amount").value;
	  t_amount = p_amount*1+o_interst*1;
	 
	 document.getElementById("t_amount").value = t_amount.toFixed(0)
	 
	 document.getElementById("n_amount").value = t_amount.toFixed(0);
        
            }
	
        };
		
        xmlhttp.open("GET", "check_date.php?q=" + ap_m, true);
        xmlhttp.send();
		
    
}
$('#t_month').keyup(function (e){
	 t_month =  document.getElementById("t_month").value;; 
               //document.getElementById("pd").value = str[3]; 
			   m_interst = document.getElementById("m_interst").value;
			   a_interst = document.getElementById("a_interst").value;
	 p_amount = document.getElementById("p_amount").value;

			   o_interst = ((t_month*m_interst)-a_interst);
			    t_amount = p_amount*1+o_interst*1;
	 document.getElementById("o_interst").value = o_interst.toFixed(0);
	  document.getElementById("t_amount").value = t_amount.toFixed(0);
	 
	 document.getElementById("n_amount").value = t_amount.toFixed(0);
});
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

$('#slip_no').keypress(function (e) {
 if(e.which == 13)
  {
	 // modal.style.display = "block";
	 var ds_no=document.getElementById("slip_no").value;
	 
	 
	 		           var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                res = this.responseText;
				
                var str = res.split("@-$");
				if(str[0] == 0){
					alert('Invalid Slip No');
					document.getElementById("slip_no").value='';
				}
				else{
                document.getElementById("dslp").value = str[0];
				document.getElementById("d_date").value = str[1];
				document.getElementById("dt_date").value = str[1];
				document.getElementById("ddname").value = str[2];
				document.getElementById("dint").value = str[3];
				document.getElementById("damount").value = str[17];
				document.getElementById("dweight").value = str[4];
				document.getElementById("didetails").value = str[11];
				document.getElementById("d_month").value = str[18];
				document.getElementById("d_days").value = str[6];
				document.getElementById("t_month").value = str[5];
				document.getElementById("p_amount").value = str[7];
				document.getElementById("m_interst").value = str[8];
				document.getElementById("a_interst").value = str[19];
				document.getElementById("o_interst").value = str[9];
				document.getElementById("t_amount").value = str[10];
				document.getElementById("n_amount").value = str[10];
				document.getElementById("delivery_date").value = str[12];
				document.getElementById("d_year").value = str[15];
				modal.style.display = "block";
				
		 			}
 };
		}
        xmlhttp.open("GET", "get_djpb.php?q=" + ds_no, true);
        xmlhttp.send();
	  document.getElementById("slip_no").value ='';
	  
 
		
}});


function save_delivery(){
	var dslp = document.getElementById("dslp").value;
	var delivery_date = document.getElementById("delivery_date").value;
	var d_month = document.getElementById("d_month").value;
	var d_days = document.getElementById("d_days").value;
	var t_month = document.getElementById("t_month").value;
	var o_interst = document.getElementById("o_interst").value;
	var t_amount = document.getElementById("t_amount").value;
	var dis = document.getElementById("dis").value;
	var n_amount = document.getElementById("n_amount").value;
	 
	 
	 var slip_no = dslp+'//-//'+delivery_date+'//-//'+d_month+'//-//'+d_days+'//-//'+t_month+'//-//'+o_interst+'//-//'+t_amount+'//-//'+dis+'//-//'+n_amount;
	 
	 		           var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                res = this.responseText;
				
                var str = res.split("@-$");
				document.getElementById("jpb_d_details").innerHTML = str[0];
				
 };
		}
        xmlhttp.open("GET", "save_djpb.php?q=" + slip_no, true);
        xmlhttp.send();
		document.getElementById("dis").value='';
	modal.style.display = "none";
}
function save_extra(){
	var extra_amount = document.getElementById("extra_amount").value;
	var dslp = document.getElementById("dslp").value;
	var n_amount = document.getElementById("n_amount").value;
	var m_interst = document.getElementById("m_interst").value;
	var d_date = document.getElementById("delivery_date").value;
	
	if(extra_amount == ''){
		alert('Enter Amount');
		
	}
	else{
	var extra = extra_amount+'//-//'+dslp+'//-//'+n_amount+'//-//'+m_interst+'//-//'+d_date;
	
	
	 		           var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                res = this.responseText;
				
                var str = res.split("@-$");
				//document.getElementById("slip_no").value = str[0];
				
 };
		}
        xmlhttp.open("GET", "save_extra_a.php?q=" + extra, true);
        xmlhttp.send();
	document.getElementById("extra_amount").value='';
	modal.style.display = "none";
}
}
function save_jama(){
	var jama_amount = document.getElementById("jama_amount").value;
	var dslp = document.getElementById("dslp").value;
	var n_amount = document.getElementById("n_amount").value;
	var m_interst = document.getElementById("m_interst").value;
	var d_date = document.getElementById("delivery_date").value;
	
	if(jama_amount == ''){
		alert('Enter Amount');
		
	}
	else{
	var extra = jama_amount+'//-//'+dslp+'//-//'+n_amount+'//-//'+m_interst+'//-//'+d_date;
	
	
	 		           var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                res = this.responseText;
				
                var str = res.split("@-$");
				//document.getElementById("slip_no").value = str[0];
				
 };
		}
        xmlhttp.open("GET", "save_jama_a.php?q=" + extra, true);
        xmlhttp.send();
	document.getElementById("jama_amount").value='';
	modal.style.display = "none";
}
}


span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>





</body>


</html>
