<?php
include "connection.php";
 $sid = $_GET['id'];

 
 	$sql = "Delete FROM customer_details where id = '$sid'";
	$result= mysqli_query($con,$sql);
	
	$url ="customers_list.php";
	redirect($url);
?>