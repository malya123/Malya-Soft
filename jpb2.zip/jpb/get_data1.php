
<?php

include "connection.php";
$q = $_REQUEST["q"];
$item_name ='';
$sql1 = "SELECT * FROM `i_products` where item_name = '".$q."' ";

 $result1= mysqli_query($con,$sql1);
 while ($row1 = mysqli_fetch_assoc($result1)) 
 {
	 

    $item_name = $row1['item_name']; 
	$pur_rate = $row1['pur_rate']; 

 
 }


if( $item_name == $q ){
	
	echo $item_name.'@-#$'.$pur_rate;

}
else
	
	echo 0;
