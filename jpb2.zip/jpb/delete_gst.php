<?php

include "connection.php";

 $sid = $_GET['id'];

 
 	$sql = "Delete FROM gst where id = '$sid'";
	$result= mysqli_query($con,$sql);
	
	$url ="add_gst_values.php";
	redirect($url);
?>