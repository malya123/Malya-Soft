<?php

include 'connection.php';
unset($_SESSION['login_user']);
unset($_SESSION['login_store']);
redirect("index.php"); // Redirecting To Home Page

?>