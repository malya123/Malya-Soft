<!DOCTYPE html>
<html>
<?php include 'connection.php'; ?>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
	
	<style>
table.table tbody td, table.table thead th {
    font-size: 13px !important;
}

td {
    padding: 1% 1% !important;
}

.table td, .table th {
    vertical-align: baseline !important;
}

h3.widget-title {
    width: 40%;
    float: left;
}
h2.widget-title {
    text-transform: uppercase;
}


.billno_line_left {
    float: left;
    width: 50%;
}

input.bill {
    width: 35%;
	 font-size: 20px;
}
.billno_line_right {
    float: right;
    text-align: right;
    width: 50%;
}

input.date {
    width: 23%;
    font-size: 20px;
}

	</style>
	
	
	
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			
			
			
			
			<!-- Page Title -->
			
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Opening Stock Reports</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
                        <li class="breadcrumb-item">Stock Management</li>
						<li class="breadcrumb-item active">Opening Stock Reports</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
		
			
			<!-- Main Content -->
			
			<?php
			
	$sql = "SELECT * FROM i_stock where id = '".$_GET['id']."' ";
	$result= mysqli_query($con,$sql);
	$row = mysqli_fetch_assoc($result);
		
		
			
			?>
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Opening Stock Reports</h3>							
							<h2 class="widget-title"><?php echo $_GET['name']; ?></h2>							
							<div class="table-responsive mb-3">
				
								<table id="tableId" class="table table-bordered table-striped">
									<thead>
										<tr>
											
											<th>S No</th>
											<th>Item Name</th>
											<th>Qty</th>
											<th>Bill Amount</th>
											<th>Pur Rate</th>
											<th>Sale Rate</th>
											<th>Sale (%)</th>
											
										</tr>
									</thead>
									<tbody>
									
									<?php
									$i=0;
	
	$sql = "SELECT * FROM opening_stock_products where sid = '".$row['id']."' ";
	$result= mysqli_query($con,$sql);
	while($row = mysqli_fetch_assoc($result)){
		
		$i++;
									
									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $row['item_name']; ?></td>
											<td><?php echo $row['qty']; ?></td>
											<td><?php echo $row['bill_amount']; ?></td>
											<td><?php echo $row['pur_rate']; ?></td>
											<td><?php echo $row['sale_rate']; ?></td>
											<td><?php echo $row['sale_per']; ?></td>
											
												
										</tr>
	<?php } ?>
									</tbody>
								</table>
								
								
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>


</body>


</html>
