
<?php 
include "connection.php";
?>

<!-- Header -->

<?php 

	$tno = $_GET['id'];
	


$sql_4 = "SELECT * from damage_products where `sid` = $tno";
$result_4= mysqli_query($con,$sql_4);
while($row_4 = mysqli_fetch_assoc($result_4)){

$item_code = $row_4['item_code'];
$qty4 = $row_4['qty'];



		$sql_i = "SELECT * from i_products where item_code = '".$item_code."'  ";
		$result_i = mysqli_query($con,$sql_i);
		$row_i = mysqli_fetch_assoc($result_i);
		
		  $new_qty3 = $row_i['qty']+$qty4;	
		$item_code = $row_i['item_code'];
		
		
	 		   $sqls = "UPDATE `i_products` SET `qty` = '".$new_qty3."' WHERE `item_code` = '".$item_code."' ";
							$result= mysqli_query($con,$sqls);

							
	
				}
			
			
$sql = "Delete from damage_products where `sid` = $tno";
$result = mysqli_query($con,$sql);


$sql = "Delete from i_damage where `id` = $tno";
$result = mysqli_query($con,$sql);

$url = "damage_reports.php";
redirect($url);


?>