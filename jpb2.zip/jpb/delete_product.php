<?php
include "connection.php";
 $id = $_GET['id'];

 
  	$sql = "Delete FROM product where id = '$id'";
	$result= mysqli_query($con,$sql);
	

	
	$url ="addproduct.php";
	redirect($url);
?>