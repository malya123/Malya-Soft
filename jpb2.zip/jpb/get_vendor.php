
<?php

include "connection.php";
$q = $_REQUEST["q"];
$vendor_name ='';
$sql1 = "SELECT * FROM `vendors` where vendor_name = '".$q."' ";

 $result1= mysqli_query($con,$sql1);
 while ($row1 = mysqli_fetch_assoc($result1)) 
 {
	 

    $id = $row1['id']; 
    $vendor_name = $row1['vendor_name']; 

 
 }


if( $vendor_name == $q ){
	
	echo $id.'@-#$'.$vendor_name;

}
else
	
	echo 0;
