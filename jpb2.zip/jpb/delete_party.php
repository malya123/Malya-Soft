<?php
include "connection.php";
 $id = $_GET['id'];

 
  	$sql = "Delete FROM party where id = '$id'";
	$result= mysqli_query($con,$sql);
	

	
	$url ="addparties.php";
	redirect($url);
?>