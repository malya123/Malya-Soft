<!DOCTYPE html>
<html>


<?php include 'connection.php'; ?>


<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	
	
	
        	<script src="js/excel1.js"></script>  
			<script src="js/excel2.js"></script>  
			<script src="js/excel3.js"></script>  
			<script src="js/excel4.js"></script> 
			<link rel="stylesheet" href="css/excel1.css" />  
			<link rel="stylesheet" href="css/excel2.css" /> 
			
			
			
			
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
	
	<style>
	
	button.btn.btn-default.xls {
    background: brown;
    color: white;
	display: none !important;
}
button.btn.btn-default.csv {
    
}
button.btn.btn-default.txt {
    display: none !important;
}


button.print_button {
    float: right;
    font-size: 15px !important;
    background-color: #e57498;
    color: #fff !important;
    margin-top: -3%;
}


</style>


</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			<!-- Page Title -->
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Price List</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
                        <li class="breadcrumb-item">Price List</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
		
			
			<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Price List</h3>	

	         
                 <div class="two">
   	                    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="  Search with Product name.." title="Type in a name" style="width: 100%;margin: 1% 0%;height:45px;font-size:18px;">
                    </div>
							
							
					

							
								<div class="table-responsive mb-3"   id="excel_table">
								    		<button class ="print_button" onclick = "printDiv()">Print Report</button>  
								<table id="tableId" class="table table-bordered table-striped" >
									<thead>
										<tr>
											
											<th>S No</th>
											<th>Item Description</th>
											<th>Item Category</th>
											<th>MRP</th>

										</tr>
									</thead>
									<tbody>
										<?php
									$i=0;
									$sql = "SELECT * FROM `items` where login_store = '".$_SESSION['login_store']."' ";
									$result = mysqli_query($con , $sql);
									while($row = mysqli_fetch_assoc($result)){
									$i++
									
									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $row['item_name'].' - '.$row['units']; ?></td>
											<td><?php echo $row['item_category']; ?></td>
											<td><?php echo $row['mrp']; ?></td>
											
					
										</tr>
									<?php } ?>
										
									</tbody>
								</table>
								
								
							</div>
							
							
							
								<div class="table-responsive mb-3"   id="print_table" style="display:none;">
								<table id="tableId" class="table table-bordered table-striped" >
									<thead>
										<tr>
											
											<th>S No</th>
											<th>Item Description</th>
											<th>Item Category</th>
											<th>MRP</th>

										</tr>
									</thead>
									<tbody>
										<?php
									$i=0;
									$sql = "SELECT * FROM `items` where login_store = '".$_SESSION['login_store']."' ";
									$result = mysqli_query($con , $sql);
									while($row = mysqli_fetch_assoc($result)){
									$i++
									
									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $row['item_name'].' - '.$row['units']; ?></td>
											<td><?php echo $row['item_category']; ?></td>
											<td><?php echo $row['mrp']; ?></td>
											
					
										</tr>
									<?php } ?>
										
									</tbody>
								</table>
								
								
							</div>
							
							
							
							<div class="table-responsive mb-3">
								<table id="tableId" class="table table-bordered table-striped" >
									<thead>
										<tr>
											
											<th>S No</th>
											<th>Item Description</th>
											<th>Item Category</th>
											<th>MRP</th>
											<th style="width: 12%;">Options</th>
											
										</tr>
									</thead>
									<tbody>
										<?php
									$i=0;
									$sql = "SELECT * FROM `items` where login_store = '".$_SESSION['login_store']."' ";
									$result = mysqli_query($con , $sql);
									while($row = mysqli_fetch_assoc($result)){
									$i++
									
									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $row['item_name'].' - '.$row['units']; ?></td>
											<td><?php echo $row['item_category']; ?></td>
											<td><?php echo $row['mrp']; ?></td>
											
										
											<td>
	<a href="edit_price.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary mt-3 mb-0"><span class="ti-pencil-alt"></span></button></a>
	<a href="delete_price.php?item_name=<?php echo $row['item_name']; ?>" onclick="return confirm('Are You Sure')" ><button type="button" class="btn btn-danger mt-3 mb-0"><span class="ti-trash"></span></button></a>
				</td>	
										</tr>
									<?php } ?>
										
									</tbody>
								</table>
								
								
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->



<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>


	<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue, txtValue2;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("tableId");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
	
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1  ) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}


 $('#excel_table').tableExport();  



function printDiv() {
     var printContents = document.getElementById('print_table').innerHTML;


  var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;

   
}



</script>


</body>


<!-- Mirrored from www.konnectplugins.com/proclinic/Vertical/add-patient.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 27 Aug 2020 10:16:55 GMT -->
</html>
