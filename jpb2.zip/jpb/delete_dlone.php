<?php
include "connection.php";
 $slip_no = $_GET['slip_no'];

 
  	$sql = "Delete FROM amount where slip_no = '$slip_no'";
	$result= mysqli_query($con,$sql);
	
	
	$sql = "Delete FROM intrest where slip_no = '$slip_no'";
	$result= mysqli_query($con,$sql);
	
	$sql = "Delete FROM lone_amount where slip_no = '$slip_no'";
	$result= mysqli_query($con,$sql);
		
	$sql = "Delete FROM extra_amount where slip_no = '$slip_no'";
	$result= mysqli_query($con,$sql);
		
	$sql = "Delete FROM jamlu where slip_no = '$slip_no'";
	$result= mysqli_query($con,$sql);
	
	
	$url ="delivery_details.php";
	redirect($url);
?>