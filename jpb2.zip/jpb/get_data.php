
<?php

include "connection.php";
$q = $_REQUEST["q"];
$item_name ='';
$sql1 = "SELECT * FROM `items` where item_name = '".$q."' ";

 $result1= mysqli_query($con,$sql1);
 while ($row1 = mysqli_fetch_assoc($result1)) 
 {
	 

    $item_name = $row1['item_name']; 
    $item_category = $row1['item_category']; 
    $units = $row1['units'];
	$mrp = $row1['mrp']; 
	$cgst = $row1['cgst']; 
	$sgst = $row1['sgst']; 
	$tot_gst = $row1['tot_gst']; 
 
 }


if( $item_name == $q ){
	
	echo $item_name.'-'.$units.'@-#$'.$units.'@-#$'.$mrp.'@-#$'.$cgst.'@-#$'.$sgst.'@-#$'.$tot_gst;

}
else
	
	echo 0;
