<?php

	include "connection.php";

	$sid = $_GET['id'];

 
 	$sql = "Delete FROM stores where id = '$sid'";
	$result= mysqli_query($con,$sql);
	
	$url ="add_store.php";
	redirect($url);
	
	
?>