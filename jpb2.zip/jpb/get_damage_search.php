<?php
include "connection.php";

if(isset($_POST['save'])){
$bill_generate =0;
$save = 1;
}
	if(isset($_POST['generate'])){
$bill_generate =1;
$save = 1;
}


	if($save==1){
	$product = $_POST['product'];
	
	$damage_id = $_POST['damage_id'];
	
	foreach($_POST['ids'] as $i){
		unset($parts);
$parts = array();
		foreach($product[$i] as $part){
			$parts[] = $part;
			
		}
		
		
		 $sql_u = "SELECT * from `damage_products` WHERE `id` = '".$i."'";
		$res_u = mysqli_query($con,$sql_u);
		$row_u = mysqli_fetch_assoc($res_u);
	 $old_qty = $row_u['qty'];
	 
	 $sql_i = "SELECT p_id,qty from i_products where item_name = '".$row_u['item_name']."' ";
		$result_i= mysqli_query($con,$sql_i);
		$row_i = mysqli_fetch_assoc($result_i);
		$qty = $row_i['qty'];
		$new_qty = $row_i['qty']+$old_qty;
		$p_id = $row_i['p_id'];
		
	    $sqls = "UPDATE `i_products` SET `qty` = '".$new_qty."' WHERE `p_id` = '".$p_id."'";
			mysqli_query($con,$sqls);
			
			
			 $sqls = "UPDATE `damage_products` SET `qty` = '".$parts[1]."', 
												  `bill_amount` = '".$parts[3]."'  WHERE `id` = '".$i."'";
			
	 
			mysqli_query($con,$sqls);
			
			$sql_i = "SELECT p_id,qty from i_products where item_name = '".$parts[0]."' ";
		$result_i= mysqli_query($con,$sql_i);
		$row_i = mysqli_fetch_assoc($result_i);
		
		 $new_qty = $row_i['qty']-$parts[1];	
		 $p_id = $row_i['p_id'];
		
		 $sqls = "UPDATE `i_products` SET `qty` = '".$new_qty."'  WHERE `p_id` = '".$p_id."'";
			mysqli_query($con,$sqls);
			
			echo '<br>';
	}
	
	
	
	$bill_amt = $_POST['bill_amt'];
	

   $sqls = "UPDATE `damage_products` SET `bill_dis` = '".$bill_dis."' WHERE `id` = '".$damage_id."'";
	mysqli_query($con,$sqls);
	

		
}



	
	$url = 'damage_reports.php';
	redirect($url);



?>