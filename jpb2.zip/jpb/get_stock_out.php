
<?php

include "connection.php";
$q = $_REQUEST["q"];
$item_name ='';
$sql1 = "SELECT * FROM `items` where item_name = '".$q."' and login_store = '".$_SESSION['login_store']."' ";

 $result1= mysqli_query($con,$sql1);
 $row1 = mysqli_fetch_assoc($result1);
 
    $item_name = $row1['item_name']; 
	$qty = $row1['qty']; 


if( $item_name == $q ){
	
	echo $item_name.'@-#$'.$qty;

}
else
	
	echo 0;
