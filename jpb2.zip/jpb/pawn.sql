-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2020 at 07:49 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pawn`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin@123');

-- --------------------------------------------------------

--
-- Table structure for table `amount`
--

CREATE TABLE `amount` (
  `id` int(11) NOT NULL,
  `slip_no` bigint(100) NOT NULL,
  `item_name` text NOT NULL,
  `qty` text NOT NULL,
  `gwt` decimal(10,3) NOT NULL,
  `swt` decimal(10,3) NOT NULL,
  `nwt` decimal(10,3) NOT NULL,
  `melting` text NOT NULL,
  `purity` decimal(10,3) NOT NULL,
  `g_rate` text NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `remark` text NOT NULL,
  `phone` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `amount`
--

INSERT INTO `amount` (`id`, `slip_no`, `item_name`, `qty`, `gwt`, `swt`, `nwt`, `melting`, `purity`, `g_rate`, `value`, `remark`, `phone`) VALUES
(9, 100, 'ring', '1', '10.000', '1.000', '9.000', '75', '6.750', '2000', '13500.00', 'kdm 22k', '9533221102'),
(10, 100, 'chain', '1', '10.000', '2.000', '8.000', '75', '6.000', '2000', '12000.00', '916', '9533221102'),
(12, 101, 'ring', '1', '10.000', '2.000', '8.000', '75', '6.000', '2000', '12000.00', 'nsadsa', '9533221102'),
(13, 101, 'chain', '1', '10.000', '2.500', '7.500', '75', '5.630', '2000', '11250.00', '1asdasd', '9533221102'),
(16, 103, 'ring ', '1', '10.000', '2.000', '8.000', '75', '6.000', '2000', '12000.00', 'fgf', '9533221102'),
(17, 103, 'chain', '1', '20.000', '1.000', '19.000', '75', '14.250', '2000', '28500.00', '', '9533221102'),
(18, 104, 'ring', '1', '5.000', '1.000', '4.000', '75', '3.000', '2000', '6000.00', 'hjkdwd d', '9533221102'),
(19, 104, 'chain', '1', '10.000', '0.000', '10.000', '75', '7.500', '2000', '15000.00', '', '9533221102'),
(21, 106, 'chicken', '1', '10.000', '5.000', '5.000', '75', '3.750', '4900', '18375.00', 'good', '9100167646'),
(22, 107, 'chain', '1', '10.000', '3.000', '7.000', '75', '5.250', '4900', '25725.00', '', '9182062389'),
(23, 108, 'ring', '1', '12.000', '2.000', '10.000', '70', '7.000', '4900', '34300.00', '', '9100167646');

-- --------------------------------------------------------

--
-- Table structure for table `customer_details`
--

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `phone` text NOT NULL,
  `s_o` text NOT NULL,
  `r_name` text NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_details`
--

INSERT INTO `customer_details` (`id`, `name`, `phone`, `s_o`, `r_name`, `address1`, `address2`) VALUES
(1, 'VMR', '9533221102', 's/o', 'anand', 'nellore magunta layout', '524003'),
(2, 'VMR', '9533221100', 's/o', 'rasas', 'nellore', 'layout'),
(3, 'ronith', '9100167646', 's/o', 'anand', 'nellore', 'magunta layout'),
(4, 'VMR', '9182062389', 's/o', 'anand', 'nellore', 'muthukur road');

-- --------------------------------------------------------

--
-- Table structure for table `gold_rate`
--

CREATE TABLE `gold_rate` (
  `id` int(11) NOT NULL,
  `rate` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gold_rate`
--

INSERT INTO `gold_rate` (`id`, `rate`) VALUES
(1, '4900');

-- --------------------------------------------------------

--
-- Table structure for table `intrest`
--

CREATE TABLE `intrest` (
  `id` int(11) NOT NULL,
  `slip_no` bigint(100) NOT NULL,
  `phone` text NOT NULL,
  `amount` text NOT NULL,
  `i_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intrest`
--

INSERT INTO `intrest` (`id`, `slip_no`, `phone`, `amount`, `i_date`) VALUES
(1, 100, '9533221102', '28400', '2020-12-24'),
(3, 101, '9533221102', '23000', '2019-12-24'),
(8, 101, '9533221102', '29900', '2020-12-24'),
(9, 103, '9533221102', '20000', '2020-12-25'),
(10, 104, '9533221102', '21000', '2020-12-25'),
(12, 106, '9100167646', '5000', '2020-12-28'),
(13, 107, '9182062389', '10000', '2020-12-28'),
(14, 108, '9100167646', '20000', '2020-12-28');

-- --------------------------------------------------------

--
-- Table structure for table `lone_amount`
--

CREATE TABLE `lone_amount` (
  `id` int(11) NOT NULL,
  `t_qty` decimal(10,3) NOT NULL,
  `t_gwt` decimal(10,3) NOT NULL,
  `t_nwt` decimal(10,3) NOT NULL,
  `t_value` decimal(10,2) NOT NULL,
  `l_amount` bigint(100) NOT NULL,
  `interest` text NOT NULL,
  `m_interest` decimal(10,2) NOT NULL,
  `a_interest` decimal(10,2) NOT NULL,
  `pay_amount` decimal(10,2) NOT NULL,
  `payment_type` text NOT NULL,
  `m_date` date NOT NULL,
  `slip_no` bigint(100) NOT NULL,
  `phone` text NOT NULL,
  `l_date` date NOT NULL,
  `status` text NOT NULL,
  `d_date` date NOT NULL,
  `month` text NOT NULL,
  `days` text NOT NULL,
  `i_month` text NOT NULL,
  `o_intrest` text NOT NULL,
  `t_amount` text NOT NULL,
  `discount` text NOT NULL,
  `n_amount` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lone_amount`
--

INSERT INTO `lone_amount` (`id`, `t_qty`, `t_gwt`, `t_nwt`, `t_value`, `l_amount`, `interest`, `m_interest`, `a_interest`, `pay_amount`, `payment_type`, `m_date`, `slip_no`, `phone`, `l_date`, `status`, `d_date`, `month`, `days`, `i_month`, `o_intrest`, `t_amount`, `discount`, `n_amount`) VALUES
(3, '2.000', '20.000', '17.000', '25500.00', 20000, '3.5', '700.00', '700.00', '19300.00', 'CASH', '2021-12-24', 100, '9533221102', '2019-12-24', 'DELIVERY', '2021-02-26', '2', '1', '2', '1988.00', '30388.00', '388', '30000.00'),
(5, '2.000', '20.000', '15.500', '23250.00', 23000, '2.5', '575.00', '575.00', '22425.00', 'CASH', '2021-12-24', 101, '9533221102', '2019-12-24', 'DELIVERY', '2021-03-17', '2', '19', '2', '1495.00', '31395.00', '95', '31300.00'),
(7, '2.000', '30.000', '27.000', '40500.00', 20000, '2', '400.00', '400.00', '19600.00', 'CASH', '2021-12-25', 103, '9533221102', '2020-12-25', '', '0000-00-00', '', '', '', '', '', '', ''),
(8, '2.000', '15.000', '14.000', '21000.00', 21000, '2', '420.00', '420.00', '20580.00', 'CASH', '2021-12-25', 104, '9533221102', '2020-12-25', '', '0000-00-00', '', '', '', '', '', '', ''),
(10, '1.000', '10.000', '5.000', '18375.00', 5000, '5', '250.00', '250.00', '4750.00', 'BANK', '2021-12-28', 106, '9100167646', '2020-12-28', '', '0000-00-00', '', '', '', '', '', '', ''),
(11, '1.000', '10.000', '7.000', '25725.00', 10000, '2', '200.00', '200.00', '9800.00', 'CASH', '2021-12-28', 107, '9182062389', '2020-12-28', '', '0000-00-00', '', '', '', '', '', '', ''),
(12, '1.000', '12.000', '10.000', '34300.00', 20000, '2', '400.00', '400.00', '19600.00', 'BANK', '2021-12-28', 108, '9100167646', '2020-12-28', '', '0000-00-00', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `melting`
--

CREATE TABLE `melting` (
  `id` int(11) NOT NULL,
  `melting` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `melting`
--

INSERT INTO `melting` (`id`, `melting`) VALUES
(1, '70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `amount`
--
ALTER TABLE `amount`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_details`
--
ALTER TABLE `customer_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gold_rate`
--
ALTER TABLE `gold_rate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `intrest`
--
ALTER TABLE `intrest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lone_amount`
--
ALTER TABLE `lone_amount`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `melting`
--
ALTER TABLE `melting`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `amount`
--
ALTER TABLE `amount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `customer_details`
--
ALTER TABLE `customer_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `gold_rate`
--
ALTER TABLE `gold_rate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `intrest`
--
ALTER TABLE `intrest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `lone_amount`
--
ALTER TABLE `lone_amount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `melting`
--
ALTER TABLE `melting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
