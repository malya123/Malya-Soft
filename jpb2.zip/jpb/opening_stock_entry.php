<!DOCTYPE html>
<html>
<?php include 'connection.php' ;?>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
	
	
	
<script src="js1/jquery.min.js"></script>
<script src="js1/select2.full.min.js"></script>
<script src="js1/jquery.inputmask.bundle.min.js"></script>


	
	<style>
	
	a.btn.btn-primary.m-b-5.m-r-2 {
    float: right;
	margin-top: 1.7%;
	}

td.span3.manufacturer {
    padding: 0.5% 0.2% !important;
}

input.form-control {
    padding: .5% .75% !important;
    height: 30px;
	font-weight: bold;
}
.table-bordered td, .table-bordered th {
    border: 0px solid #dee2e6!important;
}

th.text-center {
    font-size: 12px !important;
}

th.text-center {
    background-color: green;
    color: #fff;
}

.widget-area-2 {
    margin-top: 3px !important;
}

div#lists {
    height: 225px;
    border: 1px solid #ddd;
    width: 104%;
    overflow: auto;
    padding: 0px !important;
    margin: 1% -2%;
}


table#order {
    width: 100%;
}
thead#order_h {
    border: 1px solid #ddd;
}

td.bor {
    border: 1px solid #ddd;
}

button.btn.btn-primary.btn-lg {
    padding: 2% 5%;
    margin: 19% 20%;
    background-color: #dc6c97 !important;
}

.form-group.col-md-2 {
    margin-bottom: 0% !important;
}

input.btn.btn-primary.btn-sm {
    width: 50%;
    margin-top: 18%;
    margin-left: 20%;
}

i.ti-close {
    font-size: 13px;
    font-weight: bold;
}

	</style>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			<!-- Page Title -->
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Opening Stock Entry</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
                        <li class="breadcrumb-item">Stock Management</li>
						<li class="breadcrumb-item active">Opening Stock Entry</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
						
							<h3 class="widget-title">Opening Stock Entry</h3>
			
							<form id="pur_form" name="pur_form" method="post" action="save_opening_stock.php">
								<div class="form-row">
									
									<div class="form-group col-md-4">
										<label for="dob">Invoice Date</label>
	<input type="text" class="form-control" data-inputmask-alias="datetime" value="<?php echo date('d/m/Y'); ?>" name = "date" data-inputmask-inputformat="dd/mm/yyyy" data-mask>

									</div>
									
									<div class="form-group col-md-4">
										<label for="dob">Name</label>
		
	<input type="text" class="form-control" name="name" id="name" value="Opening Stock" readonly >
	
	</div>
								
					
									
								</div>
								
								
								<div class="table-responsive" style="margin-top: 10px">
                            <table class="table table-bordered" id="purchaseTable">
                                <thead>
                                    <tr>
										<th class="text-center" style="width:24%;" >Item Name</th>        
										<th class="text-center">Qty</th>
										<th class="text-center" >Bill Amount</th>
										<th class="text-center" >Pur Rate</th>
										<th class="text-center" >Sale Rate</th>
										<th class="text-center" >Sale (%)</th>
									</tr>
									
                                </thead>
								
								
   <tbody id="addPurchaseItem">
                        <tr>
						
													<div class="w3-col l3 width3" style="display:none">

<div class="w3-col ll6" >
<input class="selection" type="text" id = "item" name = "item"  value=""  placeholder ="" >
	</div>
</div>

    <td class="span3 manufacturer">
	
	<?php 
				$sql1 = "SELECT * FROM `items`  ORDER BY `items`.`item_name` ASC ";
				$result1= mysqli_query($con,$sql1);	
		?>

	<datalist class ="selection" name = "items" id="items" >

	<?php 
		if ($result1)
  {
	  $i=0;
  // Fetch one and one row
  
  while ($row1 = mysqli_fetch_assoc($result1)) 
    {
		
		?>
		<option value ="<?php echo $row1['item_name']; ?>"><?php echo $row1['item_name']; ?> </option>

<?php
		}	
  }
?>
</datalist>
	
	<input   class="form-control one" type="text"  name="item_name" id="item_name" list="items" onchange="get_data()" >
	</td>


	

	<td class="span3 manufacturer">
	<input   class="form-control one" type="text"  name="qty" id="qty">
	</td>
    	
    	<td class="span3 manufacturer">
	<input   class="form-control one" type="text"  name="bill_amount" id="bill_amount" onkeyup="get_gst_pur() , get_sale_per()">
	</td>
    

    
	<td class="span3 manufacturer">
	<input   class="form-control one" type="text"  name="pur_rate" id="pur_rate" onkeyup="get_sale_per()" readonly>
	</td>
    
	<td class="span3 manufacturer">
	<input   class="form-control one" type="text"  name="sale_rate" id="sale_rate" onkeyup="get_sale_per()">
	</td>
       
	<td class="span3 manufacturer">
	<input   class="form-control one" type="text"  name="sale_per" id="sale_per" onkeyup="get_sale_rate()">
	</td>
   
   <td class="span3 manufacturer" style="display:none;">
	<input   class="form-control one" type="text"  name="cgst_per" id="cgst_per" >
	</td>
   
  <td class="span3 manufacturer" style="display:none;">
	<input   class="form-control one" type="text"  name="sgst_per" id="sgst_per" >
	</td>
   
  <td class="span3 manufacturer" style="display:none;">
	<input   class="form-control one" type="text"  name="gst_per" id="gst_per" >
	</td>
   

      
	  </tr>
	  </tbody>
      

	</table>


								
                    
                        </div>
						
						
							<div class="" id = "lists">
											<table id = "order" class ="w3-threequarter" >
											
											<thead id="order_h">
											</thead>
											<tbody id="order_b">
											</tbody>

													</table>

										</div>
										
						
					<div class="form-row">
									<div class="form-group col-md-2">
										<label for="patient-name">Bill Amount</label>
										<input type="text" class="form-control" name="bill_amt" id="bill_amt">
									</div>
									
									
									<div class="form-group col-md-2 mb-3">
					<input  class="btn btn-primary btn-sm" onclick="submit_form()" value="save"  readonly>
									</div>
									
								</div>
						
							</form>
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
			
			
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<!-- <script src="js/jquery-3.2.1.min.js"></script> -->
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>
	
	<script>
	
	
		
function get_vendor_id() {
   var vendor = document.getElementById("vendor").value;


        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				
                res = this.responseText;
       
				{
				var res = res.split("@-#$");
				document.getElementById("vendor_id").value = res[0];
								
				}
            }
			
				
			if(res[0] == 0) {
			
			// $('#vendor').focus();   
				
			alert('Invalid Vendor details');
			 document.getElementById("vendor_id").value = '';
			 document.getElementById("vendor").value = '';
			  
			}
			else {
				
			}
			 
        };
		
        xmlhttp.open("GET", "get_vendor.php?q=" + vendor, true);
        xmlhttp.send();
    
}
	
	

	
	
	function get_sale_per() {
		
		   var pur_rate = document.getElementById("pur_rate").value;
		   var sale_rate = document.getElementById("sale_rate").value;
		   
		var  sale_per  = ((sale_rate *1 - pur_rate *1) / pur_rate*1) * 100;
			document.getElementById("sale_per").value =  sale_per.toFixed(2);

		
	}
	
	
	function get_sale_rate() {
		
		   var pur_rate = document.getElementById("pur_rate").value;
		   var sale_per = document.getElementById("sale_per").value;
		   
		var  sale_rate  = pur_rate*1 + ((sale_per*1 / 100) * (pur_rate*1));
			document.getElementById("sale_rate").value =  sale_rate.toFixed(2);

		
	}
	
	
	
	
	function get_gst_pur() {
		
		   var bill_amount = document.getElementById("bill_amount").value;
		   var qty = document.getElementById("qty").value;
		   
		  document.getElementById("pur_rate").value = bill_amount *1 / qty *1;

		
	}
	
	
	
	function get_data() {
   var item_name = document.getElementById("item_name").value;


        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				
                res = this.responseText;
       
				{
				var res = res.split("@-#$");
				document.getElementById("sale_rate").value = res[2];
				document.getElementById("cgst_per").value = res[3];
				document.getElementById("sgst_per").value = res[4];
				document.getElementById("gst_per").value = res[5];
								
				}
            }
			
				
			if(res[0] == 0) {
				$('#item_name').focus();   
				
			alert('Invalid item code');
			 document.getElementById("item_name").value = '';
			 document.getElementById("sale_rate").value = '';
			 document.getElementById("cgst_per").value = '';
			 document.getElementById("sgst_per").value = '';
			 document.getElementById("gst_per").value = '';
			
			  
			}
			else {
				
			}
			 
        };
		
        xmlhttp.open("GET", "get_data.php?q=" + item_name, true);
        xmlhttp.send();
    
}


	function sorting(){
var rows = $('table tr:not(:first)').detach().toArray();
rows.sort(function(rowA, rowB) {
    var textA = $(rowA).find('td:first').text();
    var textB = $(rowB).find('td:first').text();
    console.log(textA, textB);
    return textA > textB ? -1 : 1;
});

$('table').append(rows);
	}


		$('.one').keypress(function (e) {
 if(e.which == 13)
  {
    $(this).closest('td').nextAll().eq(0).find('input').focus();
  }
});


$('#item_name').change(function (e) {
	
var data = $(this).val();
if(data !=''){
    $('#qty').focus();   
} 
});


$('#qty').change(function (e) {
	
var data = $(this).val();
if(data !=''){
    $('#bill_amount').focus();   
} 
});



 function submit_form(){
			pur_form.submit();
			     }
			 
			



 function remove(id,val1){
	
	var elem = document.getElementById(id);


	 bill_amt = bill_amt-val1;

	document.getElementById("bill_amt").value =  bill_amt.toFixed(2);




elem.parentNode.removeChild(elem);
}
	

	
			 
var i=0;
var bill_amt=0;

$('#sale_per').keypress(function (e) {		
 if(e.which == 13)
  {
	  
	if(document.getElementById("item_name").value !=''){  
	  
	  
		
    var citem = document.getElementById("item").value;
	 var item_name = document.getElementById("item_name").value;
	 var qty = document.getElementById("qty").value;
	 var bill_amount = document.getElementById("bill_amount").value;
	 var pur_rate = document.getElementById("pur_rate").value;
	 var sale_rate = document.getElementById("sale_rate").value;
	 var sale_per = document.getElementById("sale_per").value;
	 var sgst_per = document.getElementById("cgst_per").value;
	 var cgst_per = document.getElementById("sgst_per").value;
	 var gst_per = document.getElementById("gst_per").value;
 


	i++;
	
	 bill_amt += bill_amount*1;
			 
	document.getElementById("bill_amt").value =  bill_amt.toFixed(2);

	


if(i == 1)
    order_h.innerHTML = order_h.innerHTML + '<tr><th>SNo</th><th>Item Name</th><th>Qty</th><th>Bill Amount</th><th>Pur Rate</th><th>Sale Rate</th><th>Sale (%)</th></tr>';
	id_citem = item_name+"@-#$"+qty+"@-#$"+bill_amount+"@-#$"+pur_rate+"@-#$"+sale_rate+"@-#$"+sale_per+"@-#$"+cgst_per+"@-#$"+sgst_per+"@-#$"+gst_per;
	

	item_val1 = bill_amount;


	var item_i = "'item"+i+"'";
		
	order_b.innerHTML = order_b.innerHTML + '<tr id ="item'+i+'"><td class="bor">'+i+'</td><td  class="bor" style ="word-wrap:break-word;">' + item_name + '</td><td class="bor">' +qty+ '</td><td class="bor">' +bill_amount+ '</td><td class="bor">' +pur_rate+ '</td><td class="bor">' +sale_rate+ '</td><td class="bor">' +sale_per+ '</td><td  class="bor" style="display:" class ="w3-col s3" style="height: auto;width: fit-content;"><a ><i class ="ti-close" onclick="remove('+item_i+','+item_val1+')"></i></a>		<input  type = "hidden" name = "item[]" value = "'+ id_citem + '"   checked /></td></tr>';
	

	 
	 document.getElementById("item_name").value= '';
	 document.getElementById("qty").value= '';
	 document.getElementById("bill_amount").value= '';
	 document.getElementById("pur_rate").value= '';
	 document.getElementById("sale_rate").value= '';
	 document.getElementById("sale_per").value= '';
	 document.getElementById("gst_per").value= '';
	 document.getElementById("cgst_per").value= '';
	 document.getElementById("sgst_per").value= '';
	 

	  
	  
	  
   
	if($('#sale_per').blur()){
		$('#item_name').focus().val('');
	}
	}
  }
});


</script>



<script>





  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd-mm-yyyy', { 'placeholder': 'dd-mm-yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm-dd-yyyy', { 'placeholder': 'mm-dd-yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      locale: {
        format: 'MM-DD-YYYY hh:mm A'
      }
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Timepicker
    $('#timepicker').datetimepicker({
      format: 'LT'
    })
    
    //Bootstrap Duallistbox
    $('.duallistbox').bootstrapDualListbox()

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    $('.my-colorpicker2').on('colorpickerChange', function(event) {
      $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
    });

    $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });

  })
</script>
</body>


</html>
