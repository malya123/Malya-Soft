
<?php

include "connection.php";
$q = $_REQUEST["q"];
$item_code ='';

 $sql2 = "SELECT * FROM `items` where item_code = '".$q."' ";
 $result2 = mysqli_query($con,$sql2);
 $row2 = mysqli_fetch_assoc($result2);
	 

    $item_code = $row2['item_code']; 
    $item_name = $row2['item_name']; 
	
	$sale_rate = $row2['mrp']; 



if( $item_code == $q ){
	
	echo $item_name.'@-#$'.$sale_rate;

}
else
	
	echo 0;
