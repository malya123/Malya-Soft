<!DOCTYPE html>
<html>


<?php include 'connection.php'; ?>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>

<style>

button.btn.btn-primary.btn-lg {
    margin: 12.5% 10%;
}


input#myCheck {
	
	width: 20px;
    height: 20px;
    margin-top: 0.2%;
    float: left;
    margin-left: 4%;
    margin-right: 2%;
}

  input#che1 , input#che2 , input#che3 , input#che4 , input#che5 , input#che6 , input#che7 ,  input#che8 , 
  input#che9 , input#che10 , input#che11 , input#che12 , input#che13 , input#che14 , input#che15 ,  input#che16 , 
  input#myCheck1_1 , input#myCheck1_2 , input#myCheck1_3 , input#myCheck1_4 , input#myCheck1_5 , input#myCheck1_6 ,input#myCheck1_7 ,input#myCheck1_8 ,
  input#myCheck2_1 , input#myCheck2_2 , input#myCheck2_3 , input#myCheck2_4 , input#myCheck2_5 , input#myCheck2_6 ,input#myCheck2_7 ,input#myCheck2_8 ,
  input#myCheck3_1 , input#myCheck3_2 , input#myCheck3_3 , input#myCheck3_4 , input#myCheck3_5 , input#myCheck3_6 ,input#myCheck3_7 ,input#myCheck3_8 ,
  input#myCheck4_1 , input#myCheck4_2 , input#myCheck4_3 , input#myCheck4_4 , input#myCheck4_5 , input#myCheck4_6 ,input#myCheck4_7 ,input#myCheck4_8 ,
  input#myCheck5_1 , input#myCheck5_2 , input#myCheck5_3 , input#myCheck5_4 , input#myCheck5_5 , input#myCheck5_6 ,input#myCheck5_7 ,input#myCheck5_8 ,
  input#myCheck6_1 , input#myCheck6_2 , input#myCheck6_3 , input#myCheck6_4 , input#myCheck6_5 , input#myCheck6_6 ,input#myCheck6_7 ,input#myCheck6_8 ,
  input#myCheck7_1 , input#myCheck7_2 , input#myCheck7_3 , input#myCheck7_4 , input#myCheck7_5 , input#myCheck7_6 ,input#myCheck7_7 ,input#myCheck7_8 ,
  input#myCheck8_1 , input#myCheck8_2 , input#myCheck8_3 , input#myCheck8_4 , input#myCheck8_5 , input#myCheck8_6 ,input#myCheck8_7 ,input#myCheck8_8 ,
  input#myCheck9_1 , input#myCheck9_2 , input#myCheck9_3 , input#myCheck9_4 , input#myCheck9_5 , input#myCheck9_6 ,input#myCheck9_7 ,input#myCheck9_8 ,
  input#myCheck10_1 , input#myCheck10_2 , input#myCheck10_3 , input#myCheck10_4 , input#myCheck10_5 , input#myCheck10_6 ,input#myCheck10_7 ,input#myCheck10_8 ,
  input#myCheck11_1 , input#myCheck11_2 , input#myCheck11_3 , input#myCheck11_4 , input#myCheck11_5 , input#myCheck11_6 ,input#myCheck11_7 ,input#myCheck11_8 ,
  input#myCheck12_1 , input#myCheck12_2 , input#myCheck12_3 , input#myCheck12_4 , input#myCheck12_5 , input#myCheck12_6 ,input#myCheck12_7 ,input#myCheck12_8 

  
  {
    height: 20px;
    width: 20px;
    margin: 1% 0%;
}


tr {
    border: 1px solid #ddd;
}

td.pad {
    width: 28% !important;
    padding: 1.45% 1%;
}


</style>

</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			
			
				
			<?php

	
if(isset($_POST["update"])){
	

 $employee_name = $_POST['employee_name'];
 $phone = $_POST['phone'];
 $address = $_POST['address'];
 $username = $_POST['username'];
 $password = $_POST['password'];
 $location = $_POST['location'];
 $store = $_POST['store'];

 $update_id = $_POST['update_id'];


	$sql = "UPDATE `users` SET `employee_name` = '".$employee_name."' , 
								 `phone` = '".$phone."' ,
								 `address` = '".$address."' ,
								 `username` = '".$username."' ,
								 `password` = '".$password."' ,
								 `store` = '".$store."' ,
								 `location` = '".$location."'  where id = '".$update_id."'";
	
	$result= mysqli_query($con,$sql);
	
 $url = 'add_logins.php';
 redirect($url); 

}
?>



			<!-- Page Title -->
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Edit Logins</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
                        <li class="breadcrumb-item">Item Management</li>
						<li class="breadcrumb-item active">Edit Logins</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			<!-- Main Content -->
			
			<?php 
			
									$sql = "SELECT * FROM `users` where id = '".$_GET['id']."' ";
									$result = mysqli_query($con , $sql);
									$row = mysqli_fetch_assoc($result);
										
			
			?>
			
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Edit Logins</h3>
							<form method="post">
								<div class="form-row">
									
									
									<div class="form-group col-md-4">
										<label for="dob">Employee Name</label>
										<input type="text" class="form-control" value="<?php echo $row['employee_name']; ?>" name="employee_name" id="employee_name">
										<input type="hidden" class="form-control" value="<?php echo $_GET['id']; ?>" name="update_id" id="update_id" required>
										</div>
									
									<div class="form-group col-md-4">
										<label for="dob">Mobile No</label>
										<input type="text" class="form-control" value="<?php echo $row['phone']; ?>"  name="phone" id="phone">
									</div>
									
									<div class="form-group col-md-4">
										<label for="dob">Address</label>
										<input type="text" class="form-control" value="<?php echo $row['address']; ?>"  name="address" id="address">
									</div>
									
									<div class="form-group col-md-4">
										<label for="patient-name">User Name</label>
										<input type="text" class="form-control" value="<?php echo $row['username']; ?>"  name="username" id="username">
									</div>
									<div class="form-group col-md-4">
										<label for="dob">Password</label>
										<input type="text" class="form-control" value="<?php echo $row['password']; ?>"  name="password" id="password">
									</div>
									
									<div class="form-group col-md-4">
										<label for="dob">Shop Location</label>
										<input type="text" class="form-control" value="<?php echo $row['location']; ?>"  name="location" id="location">
									</div>
									
										<div class="form-group col-md-4">
										<label for="dob">Store</label>
		
		<select type="text" class="form-control" name="store" id="store" required >

		<option value =""> --SELECT STORE-- </option>

		<?php 
				$sql1 = "SELECT * FROM `stores` ORDER BY `stores`.`store` ASC";
				$result1= mysqli_query($con,$sql1);	
					if ($result1)
				{
	  $i=0;
  // Fetch one and one row
  
  while ($row1 = mysqli_fetch_assoc($result1)) 
    {
		
		?>
		<option value ="<?php echo $row1['store']; ?>" <?php if($row['store'] == $row1['store'] ) echo 'Selected' ; else echo ''; ?> ><?php echo $row1['store']; ?> </option>

<?php
		}	
  }
?>
</select>
	
	</div>
								
								
									
									<div class="form-group col-md-3 mb-6">
										<button type="submit" name="update" class="btn btn-primary btn-lg">update</button>
									</div>
								</div>
							</form>
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
			
			<!-- Main Content -->
			
			<!-- /Main Content -->
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>
	
	
	<script>
	
	function addbox() {
    if (document.getElementById('myCheck').checked) {
        document.getElementById('area').style.display = '';
        document.getElementById('area1').style.display = '';
    } else {
        document.getElementById('area').style.display = 'none';
        document.getElementById('area1').style.display = 'none';

    }
}



function dis_che1() {
    if (document.getElementById('che1').checked) {
        document.getElementById('dis_che1_1').style.display = 'block';
    } else {
        document.getElementById('dis_che1_1').style.display = 'none';

    }
}


function dis_che2() {
    if (document.getElementById('che2').checked) {
        document.getElementById('dis_che2_1').style.display = 'block';
    } else {
        document.getElementById('dis_che2_1').style.display = 'none';

    }
}


function dis_che3() {
    if (document.getElementById('che3').checked) {
        document.getElementById('dis_che3_1').style.display = 'block';
        document.getElementById('dis_che3_2').style.display = 'block';
    } else {
        document.getElementById('dis_che3_1').style.display = 'none';
        document.getElementById('dis_che3_2').style.display = 'none';

    }
}


function dis_che4() {
    if (document.getElementById('che4').checked) {
        document.getElementById('dis_che4_1').style.display = 'block';
    } else {
        document.getElementById('dis_che4_1').style.display = 'none';

    }
}

function dis_che5() {
    if (document.getElementById('che5').checked) {
        document.getElementById('dis_che5_1').style.display = 'block';
    } else {
        document.getElementById('dis_che5_1').style.display = 'none';

    }
}


function dis_che6() {
    if (document.getElementById('che6').checked) {
        document.getElementById('dis_che6_1').style.display = 'block';
        document.getElementById('dis_che6_2').style.display = 'block';
    } else {
        document.getElementById('dis_che6_1').style.display = 'none';
        document.getElementById('dis_che6_2').style.display = 'none';

    }
}


function dis_che7() {
    if (document.getElementById('che7').checked) {
        document.getElementById('dis_che7_1').style.display = 'block';
    } else {
        document.getElementById('dis_che7_1').style.display = 'none';

    }
}


function dis_che8() {
    if (document.getElementById('che8').checked) {
        document.getElementById('dis_che8_1').style.display = 'block';
        document.getElementById('dis_che8_2').style.display = 'block';
    } else {
        document.getElementById('dis_che8_1').style.display = 'none';
        document.getElementById('dis_che8_2').style.display = 'none';

    }
}



function dis_che9() {
    if (document.getElementById('che9').checked) {
        document.getElementById('dis_che9_1').style.display = 'block';
    } else {
        document.getElementById('dis_che9_1').style.display = 'none';

    }
}




function dis_che10() {
    if (document.getElementById('che10').checked) {
        document.getElementById('dis_che10_1').style.display = 'block';
    } else {
        document.getElementById('dis_che10_1').style.display = 'none';

    }
}




function dis_che11() {
    if (document.getElementById('che11').checked) {
        document.getElementById('dis_che11_1').style.display = 'block';
    } else {
        document.getElementById('dis_che11_1').style.display = 'none';

    }
}




function dis_che12() {
    if (document.getElementById('che12').checked) {
        document.getElementById('dis_che12_1').style.display = 'block';
    } else {
        document.getElementById('dis_che12_1').style.display = 'none';

    }
}





function ch_val1(id) {
    if (document.getElementById('myCheck1_'+id).checked) {
        document.getElementById('myCheck1_'+id).value = '2';
    } else {
        document.getElementById('myCheck1_'+id).value = '1';

    }
}


function ch_val2(id) {
    if (document.getElementById('myCheck2_'+id).checked) {
        document.getElementById('myCheck2_'+id).value = '2';
    } else {
        document.getElementById('myCheck2_'+id).value = '1';

    }
}

function ch_val3(id) {
    if (document.getElementById('myCheck3_'+id).checked) {
        document.getElementById('myCheck3_'+id).value = '2';
    } else {
        document.getElementById('myCheck3_'+id).value = '1';

    }
}


function ch_val4(id) {
    if (document.getElementById('myCheck4_'+id).checked) {
        document.getElementById('myCheck4_'+id).value = '2';
    } else {
        document.getElementById('myCheck4_'+id).value = '1';

    }
}


function ch_val5(id) {
    if (document.getElementById('myCheck5_'+id).checked) {
        document.getElementById('myCheck5_'+id).value = '2';
    } else {
        document.getElementById('myCheck5_'+id).value = '1';

    }
}


function ch_val6(id) {
    if (document.getElementById('myCheck6_'+id).checked) {
        document.getElementById('myCheck6_'+id).value = '2';
    } else {
        document.getElementById('myCheck6_'+id).value = '1';

    }
}


function ch_val7(id) {
    if (document.getElementById('myCheck7_'+id).checked) {
        document.getElementById('myCheck7_'+id).value = '2';
    } else {
        document.getElementById('myCheck7_'+id).value = '1';

    }
}



function ch_val8(id) {
    if (document.getElementById('myCheck8_'+id).checked) {
        document.getElementById('myCheck8_'+id).value = '2';
    } else {
        document.getElementById('myCheck8_'+id).value = '1';

    }
}



function ch_val9(id) {
    if (document.getElementById('myCheck9_'+id).checked) {
        document.getElementById('myCheck9_'+id).value = '2';
    } else {
        document.getElementById('myCheck9_'+id).value = '1';

    }
}



function ch_val10(id) {
    if (document.getElementById('myCheck10_'+id).checked) {
        document.getElementById('myCheck10_'+id).value = '2';
    } else {
        document.getElementById('myCheck10_'+id).value = '1';

    }
}



function ch_val11(id) {
    if (document.getElementById('myCheck11_'+id).checked) {
        document.getElementById('myCheck11_'+id).value = '2';
    } else {
        document.getElementById('myCheck11_'+id).value = '1';

    }
}



function ch_val12(id) {
    if (document.getElementById('myCheck12_'+id).checked) {
        document.getElementById('myCheck12_'+id).value = '2';
    } else {
        document.getElementById('myCheck12_'+id).value = '1';

    }
}

	</script>

</body>


<!-- Mirrored from www.konnectplugins.com/proclinic/Vertical/add-patient.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 27 Aug 2020 10:16:55 GMT -->
</html>
