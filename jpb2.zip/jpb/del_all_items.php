<?php

include "connection.php";

 
 	$sql = "Delete FROM items where login_store = '".$_SESSION['login_store']."'  ";
	$result= mysqli_query($con,$sql);
	
	$url ="add_item.php";
	redirect($url);
?>