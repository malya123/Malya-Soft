<?php
include "connection.php";
 $sid = $_GET['id'];

 
 	$sql = "Delete FROM i_expenses where id = '$sid'";
	$result= mysqli_query($con,$sql);
	
	$url ="expenses.php";
	redirect($url);
?>