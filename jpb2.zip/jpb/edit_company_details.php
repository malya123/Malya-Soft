<!DOCTYPE html>
<html>
<?php include 'connection.php'; ?>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			
			
			
			<?php

	
if(isset($_POST["submit"])){
	

 $company_name = $_POST['company_name'];
 $gst_no = $_POST['gst_no'];
 $pan_no = $_POST['pan_no'];
 $email = $_POST['email'];
 $phone1 = $_POST['phone1'];
 $phone2 = $_POST['phone2'];
 $address = $_POST['address'];
 
 
	 $sql = "UPDATE `company_details` SET `company_name` = '".$company_name."' , 
								 `gst_no` = '".$gst_no."' ,
								 `pan_no` = '".$pan_no."' ,
								 `email` = '".$email."' ,
								 `phone1` = '".$phone1."' ,
								 `phone2` = '".$phone2."' ,
								 `address` = '".$address."' ";
	
	$result= mysqli_query($con,$sql);

 $url = 'add_company.php';
 redirect($url); 

}
?>
			<!-- Page Title -->
			
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Edit Company Details</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
						<li class="breadcrumb-item active">Edit Company Details</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			<!-- Main Content -->
			
			<?php 
			
									$sql = "SELECT * FROM `company_details` where id = '".$_GET['id']."' ";
									$result = mysqli_query($con , $sql);
									$row = mysqli_fetch_assoc($result);
										
			
			?>
			
			
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Edit  Company Details</h3>
							<form action="" method="post">
								<div class="form-row">
									<div class="form-group col-md-4">
										<label for="patient-name">Company Name</label>
										<input type="text" class="form-control" value="<?php echo $row['company_name']; ?>" name="company_name" id="company_name" required>
									</div>
									<div class="form-group col-md-4">
										<label for="dob">GST No</label>
										<input type="text" class="form-control" value="<?php echo $row['gst_no']; ?>" name="gst_no" id="gst_no" required>
									</div>
									
									<div class="form-group col-md-4">
										<label for="dob">PAN No</label>
										<input type="text" class="form-control" value="<?php echo $row['pan_no']; ?>" name="pan_no" id="pan_no" >
									</div>
									
									<div class="form-group col-md-4">
										<label for="dob">Email Id</label>
										<input type="text" class="form-control" value="<?php echo $row['email']; ?>" name="email" id="email" >
									</div>
									<div class="form-group col-md-4">
										<label for="dob">Phone 1</label>
										<input type="text" class="form-control" value="<?php echo $row['phone1']; ?>" name="phone1" id="phone1" >
									</div>
									<div class="form-group col-md-4">
										<label for="dob">phone 2</label>
										<input type="text" class="form-control" value="<?php echo $row['phone2']; ?>" name="phone2" id="phone2" >
									</div>
									
								
									<div class="form-group col-md-12">
										<label for="dob">Company Address</label>
										<input type="text" class="form-control" value="<?php echo $row['address']; ?>" name="address" id="address" >
									</div>
									
									
									<div class="form-group col-md-6 mb-3">
										<button type="submit" name="submit" class="btn btn-primary btn-lg">Update</button>
									</div>
								</div>
							</form>
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
			
			<!-- Main Content -->
			
			<!-- /Main Content -->
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>
	
	<script>
	function get_tot_gst() {
	
	cgst = document.getElementById("cgst").value;
	sgst = document.getElementById("sgst").value;
	
	document.getElementById("tot_gst").value = cgst *1 + sgst *1;
	
	}
	</script>

</body>


</html>
