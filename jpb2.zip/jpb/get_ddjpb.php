<?php 
include'connection.php';


$res = '';
$sql = "SELECT * FROM `amount` where status = 'DELIVERY' ORDER BY `d_date` DESC";
$result = mysqli_query($con,$sql);
while($row = mysqli_fetch_assoc($result)){
	$dt1 = explode("-",$row["p_date"]);
	$date = $dt1[2].'-'.$dt1[1].'-'.$dt1[0];
	$dt2 = explode("-",$row["d_date"]);
	$date2 = $dt2[2].'-'.$dt2[1].'-'.$dt2[0];
	
	$res .='<tr class="last" id="last1'.$row['id'].'">';
	
	$res .= '<td> '.$row["slip_no"].'</td>';
	$res .= '<td> '.$date.'</td>';
	//$res .= '<td> '.$row["code"].'</td>';
	$res .= '<td> '.$row["name"].'</td>';
	$res .= '<td> '.$row["s/o"].'</td>';
	$res .= '<td> '.$row["r_name"].'</td>';
	$res .= '<td> '.$row["phone"].'</td>';
	$res .= '<td> '.$row["weight"].'</td>';
	$res .= '<td> '.$row["amount"].'</td>';
	$res .= '<td> '.$row["interst"].'</td>';
	$res .= '<td> '.$row["i_amount"].'</td>';
	$res .= '<td> '.$row["amt_pay"].'</td>';
	$res .= '<td> '.$date2.'</td>';
	$res .= '<td> '.$row["o_intrest"].'</td>';
	$res .= '<td> '.$row["discount"].'</td>';
	$res .= '<td> '.$row["n_amount"].'</td>';
	


	
	$res .= '<td> <a onclick="djpb_edit('.$row["slip_no"].')" ><button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a> &nbsp;<a onclick="jpb_delete('.$row["id"].')" ><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button></a></td>';
	
}



echo $res;
?>