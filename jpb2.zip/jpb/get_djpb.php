<?php 
include'connection.php';
$q = $_REQUEST["q"];
$res_s = '';
$sql_c = "SELECT count(*) count from lone_amount where slip_no = '".$q."' and status ='' ";
$res_c = mysqli_query($con,$sql_c);
$row_c = mysqli_fetch_assoc($res_c);


 
if($row_c['count'] < 1 ){
	echo 0;
}

else{
 $sql = "SELECT * FROM `lone_amount` where slip_no = '".$q."' and status = '' ";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);

$sql_i = "SELECT * FROM `intrest` where slip_no = '".$q."'  ORDER BY `intrest`.`id` DESC";
$result_i = mysqli_query($con,$sql_i);
$row_i = mysqli_fetch_assoc($result_i);

	$dt1 = explode("-",$row['l_date']);
	 $date = $dt1[2].'-'.$dt1[1].'-'.$dt1[0];

	 
	 	$dt2 = explode("-",$row_i['i_date']);
	 $date1 = $dt2[2].'-'.$dt2[1].'-'.$dt2[0];
	 
	 
	   $t_date = date('Y-m-d');
	   $from_date = date_create($row_i['i_date']);
	   $from_date1 = date_create($row['l_date']);
	   $to_date = date_create(date('Y-m-d'));


 $ndays = 0;
 $diff = date_diff($from_date,$to_date);
 $diff1 = date_diff($from_date1,$to_date);

 
   $years = $diff->format('%y'); 
   $months = $diff->format('%m'); 
   $days = $diff->format('%d'); 
 
   $years1 = $diff1->format('%y'); 
   $months1 = $diff1->format('%m'); 
   $days1 = $diff1->format('%d'); 
   
   $amount = $row_i['amount'];
   $i_amount = ($amount*$row['interest'])/100;
   
$month1 = $years*12;
//$month2 = $years*12+$months;
$month3 = $years*12+$months;
if($days == 0 ){
	$month2 = $years*12+$months;
}
else{
if($days > 15){
$month2 = $years*12+$months+1;

}

else{
	$month2 = $years*12+$months+0.5;
}
}

if($month2 >= 12){
	$dt1 = explode("-",$row_i['i_date']);
	$n_date = ($dt1[0]+1).'-'.($dt1[1]).'-'.($dt1[2]);
	$n_iamount = $i_amount*12;
	$new_amount = $row_i['amount']+$n_iamount;
	
	$sql_su = "select count(*) as count from intrest where slip_no = '".$q."' and i_date >= '$n_date'";
	$res_su = mysqli_query($con,$sql_su);
	$row_su = mysqli_fetch_assoc($res_su);
	
	if($row_su['count'] > 0 ){
	$sql_u = "UPDATE `intrest` SET amount = '$new_amount',i_date = '$n_date' where slip_no = '".$q."' AND i_date >= '$n_date'";
	mysqli_query($con,$sql_u);
	}
	else{
	$sql_i = "INSERT INTO `intrest`( `slip_no`, `phone`, `amount`, `i_date`) VALUES ('".$q."','".$row['phone']."','".$new_amount."','".$n_date."')";	
	mysqli_query($con,$sql_i);
	}
	

}

 $o_int = $i_amount*$month2-$row['a_interest'];

$t_amount = $o_int+$row_i['amount'];

$sql_c = "SELECT * FROM `customer_details` where phone = '".$row['phone']."'";
$res_c = mysqli_query($con,$sql_c);
$row_c = mysqli_fetch_assoc($res_c);

$sql_a = "SELECT * FROM `amount` where slip_no = '".$q."'";
$res_a = mysqli_query($con,$sql_a);
while($row_a = mysqli_fetch_assoc($res_a)){
	$res_s .= ' '.$row_a["item_name"].' - '.$row_a["gwt"].' - '.$row_a["swt"].' - '.$row_a["nwt"].'';
	
}

echo $q.'@-$'.$date.'@-$'.$row_c['name'].'@-$'.$row['interest'].'@-$'.$row['t_gwt'].'@-$'.$month2.'@-$'.$days.'@-$'.$amount.'@-$'.$i_amount.'@-$'.$o_int.'@-$'.$t_amount.'@-$'.$res_s.'@-$'.$t_date.'@-$'.$row['l_amount'].'@-$'.$date1.'@-$'.$years1.'@-$'.$months1.'@-$'.$row['l_amount'].'@-$'.$month3.'@-$'.$row['a_interest'];
}
?>
