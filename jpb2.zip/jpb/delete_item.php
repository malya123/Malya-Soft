<?php

include "connection.php";

 $sid = $_GET['id'];

 
 	$sql = "Delete FROM items where id = '$sid'";
	$result= mysqli_query($con,$sql);
	
	$url ="add_item.php";
	redirect($url);
?>