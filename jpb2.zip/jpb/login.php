<!DOCTYPE html>
<html>


<!-- Mirrored from www.konnectplugins.com/proclinic/Vertical/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 27 Aug 2020 10:18:01 GMT -->
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">

	<script src="js/modernizr.min.js"></script>
	
	<style>
	span.theme-click {
    display: none !important;
}
	</style>
	
	
</head>

<body class="auth-bg">
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
	
	<?php
include "connection.php";



if(isset($_POST['submit'])){
$user=$_POST['username'];
$pass=$_POST['password'];




 $sql="select COUNT(*) as count , store from users where password='$pass' and username='$user'";
$result= mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$numRows = $row['count'];
if($numRows<1)
{
?>
<script>
alert("User and pass doesnot match");
</script>
<?php
}
else
{
	$_SESSION['login_user']=$user;
	$_SESSION['login_store']=$row['store'];
	
$url = 'sale.php';
redirect($url);
	
}
}
?>


		<!-- Page Content  -->
		<div id="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-sm-6 auth-box">
						<div class="proclinic-box-shadow">
							<h3 class="widget-title">Login</h3>
							<form  method="post"  action="" class="widget-form">
								<!-- form-group -->
								<div class="form-group row">
									<div class="col-sm-12">
										<input name="username" placeholder="Username" class="form-control" required>
									</div>
								</div>
								<!-- /.form-group -->
								<!-- form-group -->
								<div class="form-group row">
									<div class="col-sm-12">
										<input type="password" placeholder="Password" name="password" class="form-control" >
									</div>
								</div>
								<!-- /.form-group -->
								<!-- 
								<div class="form-check row">
									<div class="col-sm-12 text-left">
										<div class="custom-control custom-checkbox">
											<input class="custom-control-input" type="checkbox" id="ex-check-2">
											<label class="custom-control-label" for="ex-check-2">Remember Me</label>
										</div>
									</div>
								</div>
								 -->	
								<!-- Login Button -->			
								<div class="button-btn-block">
									<button type="submit" name="submit" class="btn btn-primary btn-lg btn-block">Login</button>
								</div>
								<!-- /Login Button -->	
								<!-- 
								<div class="auth-footer-text">
									<small>New User,
										<a href="sign-up.html">Sign Up</a> Here</small>
								</div>
								 -->
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /Page Content  -->
	</div>
	<!-- Jquery Library-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
	<script src="js/bootstrap.min.js"></script>
	<!-- Custom Script-->
	<script src="js/custom.js"></script>
</body>


<!-- Mirrored from www.konnectplugins.com/proclinic/Vertical/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 27 Aug 2020 10:18:01 GMT -->
</html>
