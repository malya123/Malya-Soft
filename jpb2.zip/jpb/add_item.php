<html lang="en">

<?php include 'connection.php'; ?>

			<script src="js/excel1.js"></script>  
			<script src="js/excel2.js"></script>  
			<script src="js/excel3.js"></script>  
			<script src="js/excel4.js"></script> 
			<link rel="stylesheet" href="css/excel1.css" />  
			<link rel="stylesheet" href="css/excel2.css" /> 
	
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
	
	<style>
table.table tbody td, table.table thead th {
    font-size: 14px !important;
}

td, th {
    padding: 5px 6px !important;
}

button.btn.btn-default.xls {
    background: brown;
    color: white;
	display: none !important;
}
button.btn.btn-default.csv {
    
}
button.btn.btn-default.txt {
    display: none !important;
}




.btn-submit {
	background: #333;
	border: #1d1d1d 1px solid;
    border-radius: 2px;
	color: #f0f0f0;
	cursor: pointer;
    padding: 5px 20px;
    font-size:0.9em;
}



#response {
    padding: 10px;
    margin-top: 10px;
    border-radius: 2px;
    display:none;
}

.success {
    background: #c7efd9;
    border: #bbe2cd 1px solid;
}

.error {
    background: #fbcfcf;
    border: #f3c6c7 1px solid;
}

div#response.display-block {
    display: block;
}

button.print_button {
    float: right;
    font-size: 15px !important;
    background-color: #e57498;
    color: #fff !important;
    margin-top: -6.6%;
    margin-right: 50%;
}

button.btn.btn-primary.btn-lg {
    margin: 5% 1% !important;
}
	</style>
	
	
	
</head>


<body>

<!-- Pre Loader -->
	
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	
	
<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			<?php
$conn = mysqli_connect("185.224.137.7","u418776047_basil_billing","Basil_billing@123","u418776047_basil_billing");
require_once('vendor/php-excel-reader/excel_reader2.php');
require_once('vendor/SpreadsheetReader.php');

if (isset($_POST["import"]))
{
    
    
  $allowedFileType = ['application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
  
  if(in_array($_FILES["file"]["type"],$allowedFileType)){

        $targetPath = 'uploads/'.$_FILES['file']['name'];
        move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);
        
        $Reader = new SpreadsheetReader($targetPath);
        
        $sheetCount = count($Reader->sheets());
        for($i=0;$i<$sheetCount;$i++)
        {
            
            $Reader->ChangeSheet($i);
            
            foreach ($Reader as $Row)
            {
          
                $item_name = "";
                if(isset($Row[1])) {
                    $item_name = mysqli_real_escape_string($conn,$Row[1]);
                }
                
                $item_category = "";
                if(isset($Row[2])) {
                    $item_category = mysqli_real_escape_string($conn,$Row[2]);
                }  

			
				
				$cgst = "";
                if(isset($Row[4])) {
                    $cgst = mysqli_real_escape_string($conn,$Row[4]);
                }
				
				$sgst = "";
                if(isset($Row[5])) {
                    $sgst = mysqli_real_escape_string($conn,$Row[5]);
                }
				$tot_gst = "";
                if(isset($Row[6])) {
                    $tot_gst = mysqli_real_escape_string($conn,$Row[6]);
                }
				$units = "";
                if(isset($Row[7])) {
                    $units = mysqli_real_escape_string($conn,$Row[7]);
                }
				$mrp = "";
                if(isset($Row[8])) {
                    $mrp = mysqli_real_escape_string($conn,$Row[8]);
                }
			
				$short = "";
                if(isset($Row[10])) {
                    $short = mysqli_real_escape_string($conn,$Row[10]);
                }
				$qty = "";
                if(isset($Row[11])) {
                    $qty = mysqli_real_escape_string($conn,$Row[11]);
                }
			
                
                if (!empty($item_name) || !empty($item_category)|| !empty($cgst)|| !empty($sgst)|| !empty($tot_gst)|| !empty($units)|| !empty($mrp)) {
                    $query = "insert into items(item_name,item_category,cgst,sgst,tot_gst,units,mrp,min_qty,short,qty,login_store) values('".$item_name."','".$item_category."','".$cgst."','".$sgst."','".$tot_gst."','".$units."','".$mrp."','10','".$short."','".$qty."','".$_SESSION['login_store']."')";
                    $result = mysqli_query($conn, $query);
                
                    if (! empty($result)) {
                        $type = "success";
                        $message = "Excel Data Imported into the Database";
                    } else {
                        $type = "error";
                        $message = "Problem in Importing Excel Data";
                    }
                }
             }
        
         }
  }
  else
  { 
        $type = "error";
        $message = "Invalid File Type. Upload Excel File.";
  }
}
?>

<?php

	
if(isset($_POST["submit"])){
	

 $item_name = $_POST['item_name'];
 $item_category = $_POST['item_category'];
 $cgst = $_POST['cgst'];
 $sgst = $_POST['sgst'];
 $tot_gst = $_POST['tot_gst'];
 $units = $_POST['units'];
 $mrp = $_POST['mrp'];
 $min_qty = $_POST['min_qty'];
 $short = $_POST['short'];
 $qty = $_POST['qty'];
 
	$sqla = "SELECT COUNT(*) as count from `units` where units = '".$units."' ";
	$resulta = mysqli_query($con , $sqla);
	$rowa = mysqli_fetch_assoc($resulta);
	$count_a = $rowa['count'];
	
 if($count_a > 0 ) {
	 
 } else {
	 
	 $sqlb = "INSERT INTO `units`( `units`) VALUES 	(  '".$units."')";

	mysqli_query($con,$sqlb);
	
 }
 
 
 
	$sqlc = "SELECT COUNT(*) as count from `gst` where item_category = '".$item_category."' ";
	$resultc = mysqli_query($con , $sqlc);
	$rowc = mysqli_fetch_assoc($resultc);
	$count_c = $rowc['count'];
	
 if($count_c > 0 ) {
	 
 } else {
	 
	 $sql1 = "INSERT INTO `gst`( `item_category`, `cgst`, `sgst`, `tot_gst`) 
						VALUES 	('".$item_category."', '".$cgst."',  '".$sgst."', '".$tot_gst."')";

	mysqli_query($con,$sql1);
	
 }

	$sql1 = "INSERT INTO `items`( `item_name`,`item_category`,`cgst`, `sgst`,`tot_gst`,`units`,`mrp`,`min_qty`, `short`,`qty`,`login_store`) 
						VALUES 	( '".$item_name."', '".$item_category."', '".$cgst."',  '".$sgst."', '".$tot_gst."', '".$units."',  '".$mrp."', '".$min_qty."' , '".$short."', '".$qty."' , '".$_SESSION['login_store']."')";

	mysqli_query($con,$sql1);

 $url = 'add_item.php?e=1';
 redirect($url); 

 }

?>


<!-- Page Title -->
			
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Add Item</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
                        <li class="breadcrumb-item">Item Management</li>
						<li class="breadcrumb-item active">Add Item</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->
			
	<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Add Item</h3>
							<form action="" method="post">
								<div class="form-row">
									<div class="form-group col-md-4">
										<label for="patient-name">Item Name</label>
										<input type="text" class="form-control one" placeholder="" name="item_name" id="item_name" required>
									</div>
									<div class="form-group col-md-4">
										<label for="dob">Item Category</label>
		
	<datalist class ="selection" name = "item_categorys" id="item_categorys" >
	<?php

	$sql = "SELECT GROUP_CONCAT(item_category) as item_categorys FROM `items` where  item_category != '' and login_store = '".$_SESSION['login_store']."' GROUP BY `item_category` ASC ";
									 
									$res = mysqli_query($con,$sql);
									$i = 0;
									$tot =0;
									while($row = mysqli_fetch_assoc($res)){
										$i++;
									 
    $code_array = explode(",",$row['item_categorys']);
	$code_array = array_unique($code_array);

foreach($code_array as $item_category){
	
	?>
	
		<option value ="<?php echo $item_category; ?>"><?php echo $item_category; ?> </option>

<?php
		
  }
									}
?>
</datalist>


										<input type="text" class="form-control one" placeholder="" list = "item_categorys" name="item_category" id="item_category" required onchange="get_gst()">
									</div>
									
								
									<div class="form-group col-md-4">
										<label for="dob">Short Name</label>
										<input type="text" class="form-control one" placeholder="" name="short" id="short" >
									</div>
									
									
									
									<div class="form-group col-md-4">
										<label for="gender">Units</label>
		<?php 
				$sql1 = "SELECT * FROM `units` ORDER BY `units`.`units` ASC";
				$result1= mysqli_query($con,$sql1);	
		?>

	<datalist class ="selection" name = "unit" id="unit" >

	<?php 
		if ($result1)
  {
	  $i=0;
  // Fetch one and one row
  
  while ($row1 = mysqli_fetch_assoc($result1)) 
    {
		
		?>
		<option value ="<?php echo $row1['units']; ?>"><?php echo $row1['units']; ?> </option>

<?php
		}	
  }
?>
</datalist>

										<input type="text" class="form-control one" placeholder=""  name="units" id="units" list="unit" required>
									</div>
									
									
									<div class="form-group col-md-4">
										<label for="dob">CGST</label>
										<input type="text" class="form-control one" placeholder="" name="cgst" id="cgst" onkeyup="get_tot_gst()">
									</div>
									<div class="form-group col-md-4">
										<label for="dob">SGST</label>
										<input type="text" class="form-control one" placeholder="" name="sgst" id="sgst" onkeyup="get_tot_gst()">
									</div>
									<div class="form-group col-md-4">
										<label for="dob">Total GST</label>
										<input type="text" class="form-control one" placeholder="" name="tot_gst" id="tot_gst" readonly>
									</div>
									
									
									
									<div class="form-group col-md-4">
										<label for="dob">MRP</label>
										<input type="text" class="form-control one" placeholder=""  name="mrp" id="mrp" required>
									</div>
									
									<div class="form-group col-md-4">
										<label for="gender">Min Qty</label>
										<input type="text" class="form-control one" placeholder=""  name="min_qty" id="min_qty" required>
									</div>
									
									<div class="form-group col-md-4">
										<label for="gender">Stock</label>
										<input type="text" class="form-control one" placeholder=""  name="qty" id="qty" required>
									</div>
									
									<div class="form-group col-md-6 mb-3">
										<button type="submit" name="submit" class="btn btn-primary btn-lg">Submit</button>
									</div>
								</div>
							</form>
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->

			
<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Items List</h3>
							
					 <div class="two">
   	                    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="  Search with Product name.." title="Type in a name" style="width: 100%;margin: 1% 0%;height:45px;font-size:18px;">
                    </div>
							
							
							
	<div class="outer-container">
        <form action="" method="post" name="frmExcelImport" id="frmExcelImport" enctype="multipart/form-data">
            <div style="width: 40%;height: 50px;float: right;">
            <div style="width: 42%; float: left;">
                <label>Choose Excel File</label>
				<input type="file" name="file" id="file" accept=".xls,.xlsx">
        
            </div>
			        <button type="submit" id="submit" name="import" class="btn-submit" style="margin-top: 3%;">Upload</button>

	<a href="del_all_items.php" onclick="return confirm('Are You Sure')" style="background: red;color: #fff;padding: 1% 3% !important;font-size: 15px;border-radius: 5px;margin-left: 15%;">
		Delete All </a>
            </div>
        
        </form>
        
    </div>
	
	
    <div id="response" class="<?php if(!empty($type)) { echo $type . " display-block"; } ?>"><?php if(!empty($message)) { echo $message; } ?></div>
							

	<div class="w3-col l5" style="width: 60%; margin:;" id="excel_table">
	   
	    <button class ="print_button" onclick = "printDiv()">Print Report</button>
	
	   <table  class="table table-bordered table-striped" style="display:none;">
									
									<tbody>
            <?php
									
									$i=0;
									$sql = "SELECT * FROM `items` where login_store = '".$_SESSION['login_store']."' ";
									$result = mysqli_query($con , $sql);
									while($row = mysqli_fetch_assoc($result)){
									$i++
									
									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $row['item_name']; ?></td>
											<td><?php echo $row['item_category']; ?></td>
											<td><?php echo $row['item_code']; ?></td>
											<td><?php echo $row['cgst']; ?></td>
											<td><?php echo $row['sgst']; ?></td>
											<td><?php echo $row['tot_gst']; ?></td>
											<td><?php echo $row['units']; ?></td>
											<td><?php echo $row['mrp']; ?></td>
											<td><?php echo $row['min_qty']; ?></td>
											<td><?php echo $row['short']; ?></td>
											<td><?php echo $row['qty']; ?></td>
									
										</tr>
									<?php } ?>
									</tbody>
								</table>
</div>


							<div class="table-responsive mb-3">
								<table id="tableId" class="table table-bordered table-striped">
									<thead>
										<tr>
											
											<th>S No</th>
											<th>Item Name</th>
											<th>Category</th>
											<th>CGST</th>
											<th>SGST</th>
											<th>Total GST</th>
											<th>Units</th>
											<th>MRP</th>
											<th>Min Qty</th>
											<th>Short Name</th>
											<th>Stock</th>
											<th style="width:10%;">Options</th>
											
										</tr>
									</thead>
									<tbody>
									
									<?php
									
									$i=0;
									$sql = "SELECT * FROM `items` where login_store = '".$_SESSION['login_store']."' ";
									$result = mysqli_query($con , $sql);
									while($row = mysqli_fetch_assoc($result)){
									$i++
									
									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $row['item_name']; ?></td>
											<td><?php echo $row['item_category']; ?></td>
											<td><?php echo $row['cgst']; ?></td>
											<td><?php echo $row['sgst']; ?></td>
											<td><?php echo $row['tot_gst']; ?></td>
											<td><?php echo $row['units']; ?></td>
											<td><?php echo $row['mrp']; ?></td>
											<td><?php echo $row['min_qty']; ?></td>
											<td><?php echo $row['short'];?></td>
											<td><?php echo $row['qty'];?></td>
											
										<td>
				<a href="edit_item.php?id=<?php echo $row['id'];?>"><button type="button" class="btn btn-primary mt-3 mb-0"><span class="ti-pencil-alt"></span></button></a>
					<a href="delete_item.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are You Sure')" ><button type="button" class="btn btn-danger mt-3 mb-0"><span class="ti-trash"></span></button></a>
										</td> 
										</tr>
									<?php } ?>
									</tbody>
								</table>
								
								
							</div>
							
							
							
							
							<div class="table-responsive mb-3" style="display:none;" id="print_table">
								<table  class="table table-bordered table-striped">
									<thead>
										<tr>
											
											<th>S No</th>
											<th>Item Name</th>
											<th>Category</th>
											<th>CGST</th>
											<th>SGST</th>
											<th>Total GST</th>
											<th>Units</th>
											<th>MRP</th>
											<th>Min Qty</th>
											<th>Stock</th>

										</tr>
									</thead>
									<tbody>
									
									<?php
									
									$i=0;
									$sql = "SELECT * FROM `items` where login_store = '".$_SESSION['login_store']."' ";
									$result = mysqli_query($con , $sql);
									while($row = mysqli_fetch_assoc($result)){
									$i++
									
									?>
										<tr>
											
											<td><?php echo $i; ?></td>
											<td><?php echo $row['item_name']; ?></td>
											<td><?php echo $row['item_category']; ?></td>
											<td><?php echo $row['cgst']; ?></td>
											<td><?php echo $row['sgst']; ?></td>
											<td><?php echo $row['tot_gst']; ?></td>
											<td><?php echo $row['units']; ?></td>
											<td><?php echo $row['mrp']; ?></td>
											<td><?php echo $row['min_qty']; ?></td>
											<td><?php echo $row['qty']; ?></td>
											
										</tr>
									<?php } ?>
									</tbody>
								</table>
								
								
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
			
  



	</div>
                                        
    <!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>
	
	<script>
	function get_tot_gst() {
	
	cgst = document.getElementById("cgst").value;
	sgst = document.getElementById("sgst").value;
	
	document.getElementById("tot_gst").value = cgst *1 + sgst *1;
	
	}
	
	function get_gst() {
   var item_category = document.getElementById("item_category").value;


        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				
                res = this.responseText;
       
				{
				var res = res.split("@-#$");
				document.getElementById("cgst").value = res[0];
				document.getElementById("sgst").value = res[1];
				document.getElementById("tot_gst").value = res[2];
				
								
				}
            }
		
			 
        };
		
        xmlhttp.open("GET", "get_gst.php?q=" + item_category, true);
        xmlhttp.send();
    
}
	
			$('.one').keypress(function (e) {
 if(e.which == 13)
  {
    $(this).closest('div').nextAll().eq(0).find('input').focus();
  }
});



	  
 $('#excel_table').tableExport();  
 
 
 function printDiv() {
     var printContents = document.getElementById('print_table').innerHTML;


  var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;

   
}


function myFunction() {
  var input, filter, table, tr, td, i, txtValue, txtValue2;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("tableId");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
	
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1  ) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}



 
 </script>
</body>


</html>

