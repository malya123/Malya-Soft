<?php 
include'connection.php';

$q = $_REQUEST["q"];



$sql = "SELECT * FROM `customer_details` where phone = '".$q."'";
$res = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($res);

echo $row['name'].'@-$'.$row['s_o'].'@-$'.$row['r_name'].'@-$'.$row['address1'].'@-$'.$row['address2'].'@-$'.$row['mandal'];
?>