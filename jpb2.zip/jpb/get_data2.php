
<?php

include "connection.php";
$q = $_REQUEST["q"];
$item_name ='';

//$sql1 = "SELECT * FROM `i_products` where item_code = '".$q."' ";

// $result1= mysqli_query($con,$sql1);
 //$row1 = mysqli_fetch_assoc($result1);
 
 
  $sql2 = "SELECT * FROM `items` where item_name = '".$q."' and login_store = '".$_SESSION['login_store']."' ";
 $result2 = mysqli_query($con,$sql2);
 $row2 = mysqli_fetch_assoc($result2);
 
 //$sql3 = "SELECT * FROM `stock_p` where item_name = '".$q."' and  login_store = '".$_SESSION['login_store']."'";
 //$result3 = mysqli_query($con,$sql3);
 //$row3 = mysqli_fetch_assoc($result3);
	 

    $item_name = $row2['item_name']; 
   /// $item_des = $row1['item_des']; 
    $units = $row2['units'];
	$sale_rate = $row2['mrp']; 
	$gst = $row2['tot_gst']; 
	$short = $row2['short'];
	if($row2['qty'] >0) {
		$qty = $row2['qty'];
	}
	else {
		$qty = 0;
	}

if( $item_name == $q){
	
	echo $row2['item_name'].'@-#$'.$units.'@-#$'.$sale_rate.'@-#$'.$gst.'@-#$'.$short.'@-#$'.$qty;

}

else
	
	echo 0;
