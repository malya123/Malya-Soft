
<?php

include "connection.php";
$q = $_REQUEST["q"];
$item_category ='';
$sql1 = "SELECT * FROM `gst` where item_category = '".$q."' ";

 $result1= mysqli_query($con,$sql1);
 while ($row1 = mysqli_fetch_assoc($result1)) 
 {
	 

    $cgst = $row1['cgst']; 
    $sgst = $row1['sgst']; 
    $tot_gst = $row1['tot_gst']; 
    $item_category = $row1['item_category']; 
  
 
 }


if( $item_category == $q ){
	
	echo $cgst.'@-#$'.$sgst.'@-#$'.$tot_gst;

}
else {
	
	echo ''.'@-#$'.''.'@-#$'.'';
}
