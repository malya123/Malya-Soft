<!DOCTYPE html>
<html>

<?php include 'connection.php'; ?>

<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">

	<script src="js/modernizr.min.js"></script>
	
	<style>
	
	.widget-area.proclinic-box-shadow.color-red {
    height: 130px;
}


	.widget-left {
    margin: 11% 0%;
}

	</style>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red theme-active" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			<!-- Page Title -->
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Dashboard</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">
							<a href="index-2.html">
								<span class="ti-home"></span>
							</a>
						</li>
						<li class="breadcrumb-item active">Dashboard</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			
			<?php 
			
			$parts = explode('-',date('Y-m-d'));
			 $date = $parts[2].'-'.$parts[1].'-'.$parts[0];


			$month = $parts[1];
			
			$sql = "SELECT sum(bill_amt) as bill_amt from `i_sale` where date = '".date('Y-m-d')."' ";
			$result = mysqli_query($con , $sql);
			$row = mysqli_fetch_assoc($result);
			$today_sale = $row['bill_amt'];
			
			$sql = "SELECT sum(bill_amt) as bill_amt from `i_sale` where month = '".$month."' ";
			$result = mysqli_query($con , $sql);
			$row = mysqli_fetch_assoc($result);
			$monthly_sale = $row['bill_amt'];
			
			
				
			$sql = "SELECT sum(bill_amt) as bill_amt from `i_purchase` where invoice_date = '".date('Y-m-d')."' ";
			$result = mysqli_query($con , $sql);
			$row = mysqli_fetch_assoc($result);
			$today_purchase = $row['bill_amt'];
			
			$sql = "SELECT sum(bill_amt) as bill_amt from `i_purchase` where month = '".$month."' ";
			$result = mysqli_query($con , $sql);
			$row = mysqli_fetch_assoc($result);
			$monthly_purchase = $row['bill_amt'];
			
			
			
					
			$sql = "SELECT sum(amount) as amount from `i_expenses` where date = '".date('Y-m-d')."' ";
			$result = mysqli_query($con , $sql);
			$row = mysqli_fetch_assoc($result);
			$today_expenses = $row['amount'];
			
			$sql = "SELECT sum(amount) as amount from `i_expenses` where month = '".$month."' ";
			$result = mysqli_query($con , $sql);
			$row = mysqli_fetch_assoc($result);
			$monthly_expenses = $row['amount'];
			
			
			$sql = "SELECT COUNT(*) as count from `i_sale` where customer_name !='' ";
			$result = mysqli_query($con , $sql);
			$row = mysqli_fetch_assoc($result);
			$customers = $row['count'];
			
			
			$sql = "SELECT COUNT(*) as count from `vendors` where vendor_name !='' ";
			$result = mysqli_query($con , $sql);
			$row = mysqli_fetch_assoc($result);
			$vendors = $row['count'];
			
			?>
			<!-- Main Content -->
			<div class="container-fluid home">


				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-4">
						<div class="widget-area proclinic-box-shadow color-red">
							<div class="widget-left">
								<span class="ti-money"></span>
							</div>
							<div class="widget-right">
								<h4 class="wiget-title">Today Sale</h4>
								<span class="numeric color-red">Rs. <?php if($today_sale > 0) echo $today_sale; else echo '0'; ?></span>
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
					<!-- Widget Item -->
					<div class="col-md-4">
						<div class="widget-area proclinic-box-shadow color-green">
							<div class="widget-left">
								<span class="ti-money"></span>
							</div>
							<div class="widget-right">
								<h4 class="wiget-title">Today Purchase</h4>
								<span class="numeric color-green">Rs. <?php if($today_purchase > 0) echo $today_purchase; else echo '0'; ?></span>
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
					<!-- Widget Item -->
					<div class="col-md-4">
						<div class="widget-area proclinic-box-shadow color-yellow">
							<div class="widget-left">
								<span class="ti-money"></span>
							</div>
							<div class="widget-right">
								<h4 class="wiget-title">Total Expenses</h4>
								<span class="numeric color-yellow">Rs. <?php if($today_expenses > 0) echo $today_expenses; else echo '0'; ?></span>
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
				</div>

			<div class="row">
					<!-- Widget Item -->
					<div class="col-md-4">
						<div class="widget-area proclinic-box-shadow color-red">
							<div class="widget-left">
								<span class="ti-money"></span>
							</div>
							<div class="widget-right">
								<h4 class="wiget-title">Monthly Sale</h4>
								<span class="numeric color-red">Rs. <?php if($monthly_sale > 0) echo $monthly_sale; else echo '0'; ?></span>
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
					<!-- Widget Item -->
					<div class="col-md-4">
						<div class="widget-area proclinic-box-shadow color-green">
							<div class="widget-left">
								<span class="ti-money"></span>
							</div>
							<div class="widget-right">
								<h4 class="wiget-title">Monthly Purchase</h4>
								<span class="numeric color-green">Rs. <?php if($monthly_purchase > 0) echo $monthly_purchase; else echo '0'; ?></span>
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
					<!-- Widget Item -->
					<div class="col-md-4">
						<div class="widget-area proclinic-box-shadow color-yellow">
							<div class="widget-left">
								<span class="ti-money"></span>
							</div>
							<div class="widget-right">
								<h4 class="wiget-title">Monthly Expenses</h4>
								<span class="numeric color-yellow">Rs. <?php if($monthly_expenses > 0) echo $monthly_expenses; else echo '0'; ?></span>
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
				</div>

			<div class="row">
					<!-- Widget Item -->
					<div class="col-md-4">
						<a href="customers_list.php">
						<div class="widget-area proclinic-box-shadow color-red">
							<div class="widget-left">
								<span class="ti-money"></span>
							</div>
							<div class="widget-right">
								<h4 class="wiget-title">Customers List</h4>
								<span class="numeric color-red"><?php if($customers > 0) echo $customers; else echo '0'; ?></span>
							</div>
						</div>
						</a>
					</div>
					<!-- /Widget Item -->
					<!-- Widget Item -->
					<div class="col-md-4">
						<a href="vendors_list.php">
						<div class="widget-area proclinic-box-shadow color-green">
							<div class="widget-left">
								<span class="ti-money"></span>
							</div>
							<div class="widget-right">
								<h4 class="wiget-title">Vendors List</h4>
								<span class="numeric color-green"><?php if($vendors > 0) echo $vendors; else echo '0'; ?></span>
							</div>
						</div>
						</a>
					</div>
					<!-- /Widget Item -->
					<!-- Widget Item -->
					<div class="col-md-4">
						<a href="purchase_required.php">
						<div class="widget-area proclinic-box-shadow color-yellow">
							<div class="widget-left">
								<span class="ti-money"></span>
							</div>
							<div class="widget-right">
								<h4 class="wiget-title">Purchase Required</h4>
								<span class="numeric color-yellow">-</span>
							</div>
						</div>
						</a>
					</div>
					<!-- /Widget Item -->
				</div>

			

				
				

			</div>
			<!-- /Main Content -->
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	
	<!-- Jquery Library-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
	<script src="js/bootstrap.min.js"></script>
	<!-- morris charts -->
	<script src="charts/js/raphael-min.js"></script>
	<script src="charts/js/morris.min.js"></script>
	<script src="js/custom-morris.js"></script>

	<!-- Custom Script-->
	<script src="js/custom.js"></script>
</body>


<!-- Mirrored from www.konnectplugins.com/proclinic/Vertical/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 27 Aug 2020 10:16:07 GMT -->
</html>
