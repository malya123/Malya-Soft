<!DOCTYPE html>
<html>

<?php include 'connection.php'; ?>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			
			
			<?php

	
if(isset($_POST["submit"])){
	

 $vendor_name = $_POST['vendor_name'];
 $phone = $_POST['phone'];
 $address = $_POST['address'];
 $gst_no = $_POST['gst_no'];
 $state = $_POST['state'];


	$sql1 = "INSERT INTO `vendors`( `vendor_name`, `phone`, `address`, `gst_no`, `state`) 
						VALUES 	( '".$vendor_name."', '".$phone."', '".$address."', '".$gst_no."',  '".$state."')";

	mysqli_query($con,$sql1);

 $url = 'add_vendor.php?e=1';
 redirect($url); 

}
?>


			<!-- Page Title -->
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Add Vendor</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
                        <li class="breadcrumb-item">Item Management</li>
						<li class="breadcrumb-item active">Add Vendor</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Add Vendor</h3>
							<form method = "post">
								<div class="form-row">
									<div class="form-group col-md-4">
										<label for="patient-name">Vendor Name</label>
										<input type="text" class="form-control" placeholder="" name="vendor_name" id="vendor_name" required>
									</div>
									<div class="form-group col-md-4">
										<label for="dob">Phone Number</label>
										<input type="text" class="form-control" placeholder="" name="phone" id="phone">
									</div>
									
									<div class="form-group col-md-4">
										<label for="dob">Address</label>
										<input type="text" class="form-control" placeholder="" name="address" id="address" required>
									</div>
									
									<div class="form-group col-md-4">
										<label for="dob">GST No</label>
										<input type="text" class="form-control" placeholder="" name="gst_no" id="gst_no">
									</div>
									<div class="form-group col-md-4">
										<label for="dob">State</label>
										<input type="text" class="form-control" placeholder="" name="state" id="state">
									</div>
									
									
									<div class="form-group col-md-6 mb-3">
										<button type="submit" name="submit" class="btn btn-primary btn-lg">Submit</button>
									</div>
								</div>
							</form>
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
			
			<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Vendors List</h3>							
							<div class="table-responsive mb-3">
								<table id="tableId" class="table table-bordered table-striped">
									<thead>
										<tr>
											
											<th>S No</th>
											<th>Vendor Name</th>
											<th>Phone Number</th>
											<th>Address</th>
											<th>GST No</th>
											<th>State</th>
											<th>Options</th>
											
										</tr>
									</thead>
									<tbody>
										<?php
									$i=0;
									$sql = "SELECT * FROM `vendors` ";
									$result = mysqli_query($con , $sql);
									while($row = mysqli_fetch_assoc($result)){
									$i++
									
									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $row['vendor_name']; ?></td>
											<td><?php echo $row['phone']; ?></td>
											<td><?php echo $row['address']; ?></td>
											<td><?php echo $row['gst_no']; ?></td>
											<td><?php echo $row['state']; ?></td>
										
											<td>
	<a href="edit_vendor.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-primary mt-3 mb-0"><span class="ti-pencil-alt"></span></button></a>
	<a href="delete_vendor.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are You Sure')" ><button type="button" class="btn btn-danger mt-3 mb-0"><span class="ti-trash"></span></button></a>
										</td>	
										</tr>
									<?php } ?>
										
									</tbody>
								</table>
								
								
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>

</body>


<!-- Mirrored from www.konnectplugins.com/proclinic/Vertical/add-patient.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 27 Aug 2020 10:16:55 GMT -->
</html>
