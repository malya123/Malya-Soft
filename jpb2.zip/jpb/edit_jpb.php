<?php 
include'connection.php';
$q = $_REQUEST["q"];
$sql_m = "SELECT max(slip_no) as max FROM `amount` ";
$result_m = mysqli_query($con,$sql_m);
$row_m = mysqli_fetch_assoc($result_m);

$slip = $row_m['max']+1;

 $sql = "SELECT * FROM `amount` where id = '".$q."' ";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);

$d = explode("-",$row['p_date']);
$date = $d[2].'-'.$d[1].'-'.$d[0];

echo $row['slip_no']."@-$".$date."@-$".$row['name']."@-$".$row['s/o']."@-$".$row['r_name']."@-$".$row['phone']."@-$".$row['weight']."@-$".$row['amount']."@-$".$row['interst']."@-$".$row['i_details']."@-$".$row['i_amount']."@-$".$row['amt_pay']."@-$".$slip;
?>