<html lang="en">

<?php include 'connection.php'; ?>

			<script src="js/excel1.js"></script>  
			<script src="js/excel2.js"></script>  
			<script src="js/excel3.js"></script>  
			<script src="js/excel4.js"></script> 
			<link rel="stylesheet" href="css/excel1.css" />  
			<link rel="stylesheet" href="css/excel2.css" /> 
	
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>PRINCE JEWELLERY</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
	
	<style>
table.table tbody td, table.table thead th {
    font-size: 14px !important;
}

td, th {
    padding: 5px 6px !important;
}

button.btn.btn-default.xls {
    background: brown;
    color: white;
	display: none !important;
}
button.btn.btn-default.csv {
    
}
button.btn.btn-default.txt {
    display: none !important;
}




.btn-submit {
	background: #333;
	border: #1d1d1d 1px solid;
    border-radius: 2px;
	color: #f0f0f0;
	cursor: pointer;
    padding: 5px 20px;
    font-size:0.9em;
}



#response {
    padding: 10px;
    margin-top: 10px;
    border-radius: 2px;
    display:none;
}

.success {
    background: #c7efd9;
    border: #bbe2cd 1px solid;
}

.error {
    background: #fbcfcf;
    border: #f3c6c7 1px solid;
}

div#response.display-block {
    display: block;
}

button.print_button {
    float: right;
    font-size: 15px !important;
    background-color: #e57498;
    color: #fff !important;
    margin-top: -6.6%;
    margin-right: 50%;
}

button.btn.btn-primary.btn-lg {
    margin: 5% 1% !important;
}
	</style>
	
	
	
</head>


<body>

<!-- Pre Loader -->
	
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	
	
<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->


<!-- Page Title -->
			
			
			<!-- /Page Title -->
			
	<!-- Main Content -->
		
			<!-- /Main Content -->

			
<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Loan List</h3>
							
					 <div class="two">
   	                    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="  Search with Slip No.." title="Type in a name" style="width: 100%;margin: 1% 0%;height:45px;font-size:18px;">
                    </div>
							
							
							
	<div class="outer-container">
        <form action="" method="post" name="frmExcelImport" id="frmExcelImport" enctype="multipart/form-data">
            <div style="width: 40%;height: 50px;float: right;">
          


            </div>
        
        </form>
        
    </div>
	
	
   
							



							<div class="table-responsive mb-3">
								<table  class="table table-bordered table-striped" id="print_table">
									<thead>
										<tr>
											
											<th>S No</th>
											<th>Slip No</th>
											<th>Phone</th>
											<th>Name</th>
											
											<th>Action</th>
													
										
											
										</tr>
									</thead>
									<tbody>
									
									<?php
									
									$i=0;
									$sql = "SELECT DISTINCT slip_no,phone FROM `jamlu` ";
									$result = mysqli_query($con,$sql);
									while($row = mysqli_fetch_assoc($result)){
										
									$i++;
									$sql_c = "SELECT * FROM `customer_details` where phone = '".$row['phone']."'";
									$res_c = mysqli_query($con,$sql_c);
									$row_c = mysqli_fetch_assoc($res_c)
									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $row['slip_no']; ?></td>
											<td><?php echo $row['phone']; ?></td>
											<td><?php echo $row_c['name']; ?></td>
											
											
											
										<td>
<a href="view_jama_details.php?slip_no=<?php echo $row['slip_no'];?>"><button type="button" class="btn btn-primary mt-3 mb-0"><i class="fa fa-eye"></i></button></a>

										</td> 
										</tr>
									<?php } ?>
									</tbody>
								</table>
								
								
							</div>
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
			
  



	</div>
                                        
    <!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>
	
	<script>
	function get_tot_gst() {
	
	cgst = document.getElementById("cgst").value;
	sgst = document.getElementById("sgst").value;
	
	document.getElementById("tot_gst").value = cgst *1 + sgst *1;
	
	}
	
	function get_gst() {
   var item_category = document.getElementById("item_category").value;


        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				
                res = this.responseText;
       
				{
				var res = res.split("@-#$");
				document.getElementById("cgst").value = res[0];
				document.getElementById("sgst").value = res[1];
				document.getElementById("tot_gst").value = res[2];
				
								
				}
            }
		
			 
        };
		
        xmlhttp.open("GET", "get_gst.php?q=" + item_category, true);
        xmlhttp.send();
    
}
	
			$('.one').keypress(function (e) {
 if(e.which == 13)
  {
    $(this).closest('div').nextAll().eq(0).find('input').focus();
  }
});



	  
 $('#excel_table').tableExport();  
 
 
 function printDiv() {
     var printContents = document.getElementById('print_table').innerHTML;


  var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;

   
}


function myFunction() {
  var input, filter, table, tr, td, i, txtValue, txtValue2;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("print_table");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
	
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1  ) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}



 
 </script>
</body>


</html>

