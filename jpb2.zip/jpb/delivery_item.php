<!DOCTYPE html>
<html>
<?php include 'connection.php'; ?>

<head>
    
    <script src="js/excel1.js"></script>  
			<script src="js/excel2.js"></script>  
			<script src="js/excel3.js"></script>  
			<script src="js/excel4.js"></script> 
			<link rel="stylesheet" href="css/excel1.css" />  
			<link rel="stylesheet" href="css/excel2.css" /> 
			
			
			
			
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>PRINCE JEWELLERY</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
	
	
	
	<style>
table.table tbody td, table.table thead th {
    font-size: 13px !important;
}

td {
    padding: 0% 1% !important;
}

.table td, .table th {
    vertical-align: baseline !important;
}

tr.grand {
    background-color: khaki;
    font-weight: bold;
}

	
	button.btn.btn-default.xls {
    background: brown;
    color: white;
	display: none !important;
}
button.btn.btn-default.csv {
    
}
button.btn.btn-default.txt {
    display: none !important;
}


button.print_button {
    float: right;
    font-size: 15px !important;
    background-color: #e57498;
    color: #fff !important;
    margin-top: -3%;
    border-color: #e57498;
    margin-right: 14%;
}


.Area {
    margin-top: 3%;
}


label {
    display: inline-block;
    margin-bottom: .5rem;
    font-size: 17px;
}

.Ars {
    margin-top: 3%;
}

.Amount_details {
    margin-top: 3%;
}

</style>
	
	
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			
			
			
			
			<!-- Page Title
			
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Sale Reports</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
                        <li class="breadcrumb-item">Sale Management</li>
						<li class="breadcrumb-item active">Sale Reports</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
		
			
			<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Delivery Items</h3>	

                     <div class="two">
   	<input type="text" id="myInput" onkeyup="myFunction()" placeholder="  Search with Customer name / Phone No / Customer Code / " title="Type in a name" style="width: 100%;margin: 1% 0%;height:45px;font-size:18px;" >
</div>



               <div class="form-row">
								<div class="col-md-12">
						<div class="Area">
							<h3 class="widget-title">Customer Details</h3></div>
								
									<table id="tableId" class="table table-bordered table-striped" >
									<thead style="font-size:23px;">
										<tr>
											
											<td style="text-align:left;width: 33.33%; border: hidden;">Customer Name</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										<tr>
											
											<td style="text-align:left;
    width: 33.33%;border: hidden;">S/0,W/o,D/o</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
										
										</tr>
										<tr>
											
											<td style="text-align:left;
    width: 33.33%;border: hidden;">Mobile No</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										
										<tr>
											
											<td style="text-align:left;
    width: 33.33%; border: hidden;">Address</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										
										<tr>
											
											<td style="text-align:left;
    width: 33.33%;border: hidden;">Customer code</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										
										
										<tr>
											
											<td style="text-align:left;
    width: 33.33%;border: hidden;">Loan No</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										
										
										
										
										
										
										
										
										
										
										
									</thead></table>
										
										<div class="col-md-12">
						<div class="Ars">
							<h3 class="widget-title">Loan Details</h3>
							
							</div>
									<table id="tableId" class="table table-bordered table-striped" >
									<thead style="font-size:23px;">
										<tr>
											
											<td style="text-align:left;width: 33.33%; border: hidden;">Item Name</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										<tr>
											
											<td style="text-align:left;
    width: 33.33%;border: hidden;">Starting Date</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
										
										</tr>
										<tr>
											
											<td style="text-align:left;
    width: 33.33%;border: hidden;">Interest Gross Wt</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										
										<tr>
											
											<td style="text-align:left;
    width: 33.33%; border: hidden;">Interest Net Wt</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										
										<tr>
											
											<td style="text-align:left;
    width: 33.33%; border: hidden;">Loan Amount</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										
										<tr>
											
											<td style="text-align:left;
    width: 33.33%; border: hidden;">Interest Rate</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										
										<tr>
											
											<td style="text-align:left;
    width: 33.33%; border: hidden;">Advance Amount</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										
										
										<tr>
											
											<td style="text-align:left;
    width: 33.33%; border: hidden;">Net Payable</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>								
									</thead></table>
									
									<div class="Amount_details">
							<h3 class="widget-title">Amount Details</h3>
							
							</div>
									<table id="tableId" class="table table-bordered table-striped" >
									<thead style="font-size:23px;">
										<tr>
											
											<td style="text-align:left;width: 33.33%; border: hidden;">Total Loan Amount</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
											
										</tr>
										<tr>
											
											<td style="text-align:left;
    width: 33.33%;border: hidden;">Interest Amount</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
										
										</tr>
										
										<tr>
											
											<td style="text-align:left;
    width: 33.33%;border: hidden;">Total Days</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
										
										</tr>
										
										<td style="text-align:left;
    width: 33.33%;border: hidden;">Total Outstanding Amount</td>
											<td style="border: hidden;">:</td>
											<td style="border: hidden;">ronith</td>
										
										</tr>										
										</thead></table>
						<div class="new_butt" style="    margin-left: 75%;">			
                       <button class="print_button" onclick="">Reset</button>
							<button class="print_button" onclick="">Release Item</button>
							</div>
							
							
							
							<div class="table-responsive mb-3" style="display:none;" id="print_table">
								<table id="tableId" class="table table-bordered table-striped">
									<thead>
										<tr>
											
											<th>S No</th>
											<th style="width: 9% !important;">Date</th>
											<th>Bill No</th>
											<th>Customer Name</th>
											<th style="   width: 10% !important;">Phone</th>
											<th>Bill Amt</th>
											<th>Dis(%)</th>
											<th>Dis(Rs)</th>
											<th style="   width: 10% !important;">Paid Amt</th>
											<th>Balance</th>
											<th>Payment</th>

										</tr>
									</thead>
									<tbody>
									
									<?php
									$i=0;
									$bill_amt=0;
									$advance=0;
									$net_amount=0;
									$paid_amount=0;
									$bill_dis_rs=0;
									$balance=0;
	
$sql = "SELECT * FROM i_sale where login_store = '".$_SESSION['login_store']."' ORDER BY `i_sale`.`id` DESC ";
	
	$result= mysqli_query($con,$sql);
		if($result){
while($row = mysqli_fetch_assoc($result)){
	$i++;
	
	$bill_amt += $row['bill_amt'];
	$advance += $row['advance'];
	$net_amount += $row['net_amount'];
	$bill_dis_rs += $row['bill_dis_rs'];
	$balance += $row['balance'];
	$paid_amount = $advance +  $net_amount;
									
									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo decode_date($row['date']); ?></td>
											<td><?php echo $row['bill_no']; ?></td>
											<td><?php echo $row['customer_name']; ?></td>
											<td><?php echo $row['phone']; ?></td>
											<td><?php echo $row['bill_amt']; ?></td>
											<td><?php echo $row['bill_dis_per']; ?></td>
											<td><?php echo $row['bill_dis_rs']; ?></td>
											<td><?php echo $row['advance'] + $row['net_amount']; ?></td>
											<td><?php echo $row['balance']; ?></td>
											<td><?php echo $row['invoice_type']; ?></td>
										
										</tr>
	<?php } } ?>
	
			<tr class="grand">
			<td colspan = "5">Grand Total</td>
			<td>Rs. <?php echo $bill_amt; ?></td>
			<td></td>
			<td>Rs. <?php echo $bill_dis_rs; ?></td>
			<td>Rs. <?php echo $paid_amount; ?></td>
			<td>Rs. <?php echo $balance; ?></td>
			
			</tr>
		
		
									</tbody>
								</table>
								
								
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue, txtValue2;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("tableId");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    td2 = tr[i].getElementsByTagName("td")[2];
    td3 = tr[i].getElementsByTagName("td")[3];
    td4 = tr[i].getElementsByTagName("td")[4];
    
	
    if (td) {
      txtValue = td.textContent || td.innerText;
      txtValue2 = td2.textContent || td2.innerText;
      txtValue3 = td3.textContent || td3.innerText;
      txtValue4 = td4.textContent || td4.innerText;
	  
      if (txtValue.toUpperCase().indexOf(filter) > -1 || txtValue2.toUpperCase().indexOf(filter) > -1 || txtValue3.toUpperCase().indexOf(filter) > -1  || txtValue4.toUpperCase().indexOf(filter) > -1  ) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}


 $('#excel_table').tableExport();  



function printDiv() {
     var printContents = document.getElementById('print_table').innerHTML;


  var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;

   
}


</script>


</body>


</html>
