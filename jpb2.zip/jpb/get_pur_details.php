<?php

include "connection.php";

$q = $_REQUEST["q"];
$pres = 'n';

 
  $sql2 = "SELECT * FROM `i_purchase` where invoice_no = '".$q."' ";
  $result2= mysqli_query($con,$sql2);
  if($result2){
	 $pres = '';
	$row2 = mysqli_fetch_assoc($result2); 
	 $sql3 = "SELECT * FROM `i_pur_products` where pid = '".$row2['id']."'";
 $result3= mysqli_query($con,$sql3);
 $ct =mysqli_num_rows($result3);
 $j=0;
 while($row3 = mysqli_fetch_assoc($result3)){ 
	$j++;
	 if($j>1)
	 $pres .= '#-#';
 $pres .= $row3['item_name'].'@-@'.$row3['qty'].'@-@'.$row3['pur_rate'].'@-@'.$row3['bill_amount'];
	 
			}
		}
 


if($ct<1)
	 echo $q.'#--#n';
	 else if($ct>0)

 echo $q.'#--#'.$pres;
 else '';