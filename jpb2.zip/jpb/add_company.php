<!DOCTYPE html>
<html>
<?php include 'connection.php'; ?>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			
			
			
			<?php

	
if(isset($_POST["submit"])){
	

 $company_name = $_POST['company_name'];
 $gst_no = $_POST['gst_no'];
 $pan_no = $_POST['pan_no'];
 $email = $_POST['email'];
 $phone1 = $_POST['phone1'];
 $phone2 = $_POST['phone2'];
 $address = $_POST['address'];
 


 
	$sqla = "SELECT COUNT(*) as count from `company_details` ";
	$resulta = mysqli_query($con , $sqla);
	$rowa = mysqli_fetch_assoc($resulta);
	$count_a = $rowa['count'];
	
 if($count_a > 0 ) {
	 ?>
	 
	 <script>
alert("Company Details already added");
</script>


	 <?php 
	 
 } else {
	 
	$sql1 = "INSERT INTO `company_details`( `company_name`, `gst_no`, `pan_no`, `email`, `phone1`, `phone2`, `address` ) 
						VALUES 	( '".$company_name."', '".$gst_no."', '".$pan_no."', '".$email."',  '".$phone1."', '".$phone2."', '".$address."')";

	$result = mysqli_query($con,$sql1);
	
	if($result) { ?>
	
		 <script>alert('Deatails Added Successfully');</script>

<?php 
}
	
 }
 
 

	

 $url = 'add_company.php?e=1';
 redirect($url); 

}
?>
			<!-- Page Title -->
			
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Add Company Details</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
						<li class="breadcrumb-item active">Add Company Details</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Add  Company Details</h3>
							<form action="" method="post">
								<div class="form-row">
									<div class="form-group col-md-4">
										<label for="patient-name">Company Name</label>
										<input type="text" class="form-control" placeholder="" name="company_name" id="company_name" required>
									</div>
									<div class="form-group col-md-4">
										<label for="dob">GST No</label>
										<input type="text" class="form-control" placeholder="" name="gst_no" id="gst_no" required>
									</div>
									
									<div class="form-group col-md-4">
										<label for="dob">PAN No</label>
										<input type="text" class="form-control" placeholder="" name="pan_no" id="pan_no" >
									</div>
									
									<div class="form-group col-md-4">
										<label for="dob">Email Id</label>
										<input type="text" class="form-control" placeholder="" name="email" id="email" >
									</div>
									<div class="form-group col-md-4">
										<label for="dob">Phone 1</label>
										<input type="text" class="form-control" placeholder="" name="phone1" id="phone1" >
									</div>
									<div class="form-group col-md-4">
										<label for="dob">phone 2</label>
										<input type="text" class="form-control" placeholder="" name="phone2" id="phone2" >
									</div>

									
									
									<div class="form-group col-md-12">
										<label for="dob"> Address</label>
										<input type="text" class="form-control" placeholder="" name="address" id="address" >
									</div>
									
									
									<div class="form-group col-md-6 mb-3">
										<button type="submit" name="submit" class="btn btn-primary btn-lg">Submit</button>
									</div>
								</div>
							</form>
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
			
			<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Company Details</h3>							
							<div class="table-responsive mb-3">
								<table id="tableId" class="table table-bordered table-striped">
									<thead>
										<tr>
											
											<th>Company Name</th>
											<th>GST No</th>
											<th>PAN No</th>
											<th>Email Id</th>
											<th>Phone 1</th>
											<th>Phone 2</th>
											<th>Branch Address</th>
											<th>Options</th>
											
											
										</tr>
									</thead>
									<tbody>
									
									<?php
									$i=0;
									$sql = "SELECT * FROM `company_details` ";
									$result = mysqli_query($con , $sql);
									while($row = mysqli_fetch_assoc($result)){
									$i++
									
									?>
										<tr>
											<td><?php echo $row['company_name']; ?></td>
											<td><?php echo $row['gst_no']; ?></td>
											<td><?php echo $row['pan_no']; ?></td>
											<td><?php echo $row['email']; ?></td>
											<td><?php echo $row['phone1']; ?></td>
											<td><?php echo $row['phone2']; ?></td>
											<td><?php echo $row['address']; ?></td>
											
											
											<td>
				<a href="edit_company_details.php?id=<?php echo $row['id'];?>"><button type="button" class="btn btn-primary mt-3 mb-0"><span class="ti-pencil-alt"></span></button></a>
										</td>	
										</tr>
									<?php } ?>
									</tbody>
								</table>
								
								
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>
	
	<script>
	function get_tot_gst() {
	
	cgst = document.getElementById("cgst").value;
	sgst = document.getElementById("sgst").value;
	
	document.getElementById("tot_gst").value = cgst *1 + sgst *1;
	
	}
	</script>

</body>


</html>
