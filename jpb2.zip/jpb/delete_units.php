<?php

include "connection.php";

 $sid = $_GET['id'];

 
 	$sql = "Delete FROM units where id = '$sid'";
	$result= mysqli_query($con,$sql);
	
	$url ="add_units.php";
	redirect($url);
?>