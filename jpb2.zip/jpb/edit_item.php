<!DOCTYPE html>
<html>
<?php include 'connection.php'; ?>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->
					<?php include 'top_nav.php'; ?>

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			
			
			
			<?php

	
if(isset($_POST["update"])){
	

 $update_id = $_POST['update_id'];
 
 $item_name = $_POST['item_name'];
 $item_category = $_POST['item_category'];
 $cgst = $_POST['cgst'];
 $sgst = $_POST['sgst'];
 $tot_gst = $_POST['tot_gst'];
 $units = $_POST['units'];
 $mrp = $_POST['mrp'];
 $min_qty = $_POST['min_qty'];
 $short = $_POST['short'];
 $qty = $_POST['qty'];
 
	$sqla = "SELECT COUNT(*) as count from `units` where units = '".$units."' ";
	$resulta = mysqli_query($con , $sqla);
	$rowa = mysqli_fetch_assoc($resulta);
	$count_a = $rowa['count'];
	
 if($count_a > 0 ) {
	 
 } else {
	 
	 $sqlb = "INSERT INTO `units`( `units`) VALUES 	(  '".$units."')";

	mysqli_query($con,$sqlb);
	
 }
 
 
 
	$sqlc = "SELECT COUNT(*) as count from `gst` where item_category = '".$item_category."' ";
	$resultc = mysqli_query($con , $sqlc);
	$rowc = mysqli_fetch_assoc($resultc);
	$count_c = $rowc['count'];
	
 if($count_c > 0 ) {
	 
 } else {
	 
	 $sql1 = "INSERT INTO `gst`( `item_category`, `cgst`, `sgst`, `tot_gst`) 
						VALUES 	('".$item_category."', '".$cgst."',  '".$sgst."', '".$tot_gst."')";

	mysqli_query($con,$sql1);
	
 }


 $sql = "UPDATE `items` SET `item_name` = '".$item_name."' , 
								 `item_category` = '".$item_category."' ,
								 `cgst` = '".$cgst."' ,
								 `sgst` = '".$sgst."' ,
								 `tot_gst` = '".$tot_gst."' ,
								 `units` = '".$units."' ,
								 `mrp` = '".$mrp."' ,
								 `short` = '".$short."' ,
								 `min_qty` = '".$min_qty."',
								 `qty` = '".$qty."'  where id = '".$update_id."'";
	
	$result= mysqli_query($con,$sql);
	

 $url = 'add_item.php';
 redirect($url); 

}
?>
			<!-- Page Title -->
			
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Edit Item</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
                        <li class="breadcrumb-item">Item Management</li>
						<li class="breadcrumb-item active">Edit Item</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			<!-- Main Content -->
			
			<?php 
			
									$sql = "SELECT * FROM `items` where id = '".$_GET['id']."' ";
									$result = mysqli_query($con , $sql);
									$row = mysqli_fetch_assoc($result);
										
			
			?>
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Edit Item</h3>
							<form action="" method="post">
								<div class="form-row">
								    
								    	
									
									
									<div class="form-group col-md-4">
										<label for="patient-name">Item Name</label>
										<input type="text" class="form-control" value="<?php echo $row['item_name']; ?>" name="item_name" id="item_name" required>
										<input type="hidden" class="form-control" value="<?php echo $_GET['id']; ?>" name="update_id" id="update_id" required>
									</div>
									
									
									
									<div class="form-group col-md-4">
										<label for="dob">Item Category</label>
										
																		<?php 
				$sql1 = "SELECT * FROM `gst` ORDER BY `gst`.`item_category` ASC";
				$result1= mysqli_query($con,$sql1);	
		?>

	<datalist class ="selection" name = "item_categorys" id="item_categorys" >

	<?php 
		if ($result1)
  {
	  $i=0;
  // Fetch one and one row
  
  while ($row1 = mysqli_fetch_assoc($result1)) 
    {
		
		?>
		<option value ="<?php echo $row1['item_category']; ?>"><?php echo $row1['item_category']; ?> </option>

<?php
		}	
  }
?>
</datalist>


	<input type="text" class="form-control" list = "item_categorys"  value="<?php echo $row['item_category']; ?>" name="item_category" id="item_category" required>
									</div>
									
									<div class="form-group col-md-4">
										<label for="dob">Short Name</label>
										<input type="text" class="form-control" value="<?php echo $row['short']; ?>" name="short" id="short" >
									</div>
									
										<div class="form-group col-md-4">
										<label for="gender">Units</label>
		<?php 
				$sql1 = "SELECT * FROM `units` ORDER BY `units`.`units` ASC";
				$result1= mysqli_query($con,$sql1);	
		?>

	<datalist class ="selection" name = "unit" id="unit" >

	<?php 
		if ($result1)
  {
	  $i=0;
  // Fetch one and one row
  
  while ($row1 = mysqli_fetch_assoc($result1)) 
    {
		
		?>
		<option value ="<?php echo $row1['units']; ?>"><?php echo $row1['units']; ?> </option>

<?php
		}	
  }
?>
</datalist>

										<input type="text" class="form-control" value="<?php echo $row['units']; ?>"  name="units" id="units" list="unit" required>
									</div>
									
									
									
									
								
									
									<div class="form-group col-md-4">
										<label for="dob">CGST</label>
										<input type="text" class="form-control" value="<?php echo $row['cgst']; ?>" name="cgst" id="cgst" onkeyup="get_tot_gst()">
									</div>
									<div class="form-group col-md-4">
										<label for="dob">SGST</label>
										<input type="text" class="form-control" value="<?php echo $row['sgst']; ?>" name="sgst" id="sgst" onkeyup="get_tot_gst()">
									</div>
									<div class="form-group col-md-4">
										<label for="dob">Total GST</label>
										<input type="text" class="form-control" value="<?php echo $row['tot_gst']; ?>" name="tot_gst" id="tot_gst" readonly>
									</div>
									
								
									
									<div class="form-group col-md-4">
										<label for="dob">MRP</label>
										<input type="text" class="form-control" value="<?php echo $row['mrp']; ?>"  name="mrp" id="mrp" required>
									</div>
									
									<div class="form-group col-md-4">
										<label for="gender">Min Qty</label>
										<input type="text" class="form-control" value="<?php echo $row['min_qty']; ?>"  name="min_qty" id="min_qty" required>
									</div>
									<div class="form-group col-md-4">
										<label for="gender">Stock</label>
										<input type="text" class="form-control" value="<?php echo $row['qty']; ?>"  name="qty" id="qty" required>
									</div>
									
									<div class="form-group col-md-6 mb-3">
										<button type="submit" name="update" class="btn btn-primary btn-lg">Update</button>
									</div>
								</div>
							</form>
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			<!-- /Main Content -->
			
			<!-- Main Content -->
			
			<!-- /Main Content -->
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>
	
	<script>
	function get_tot_gst() {
	
	cgst = document.getElementById("cgst").value;
	sgst = document.getElementById("sgst").value;
	
	document.getElementById("tot_gst").value = cgst *1 + sgst *1;
	
	}
	</script>

</body>


<!-- Mirrored from www.konnectplugins.com/proclinic/Vertical/add-patient.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 27 Aug 2020 10:16:55 GMT -->
</html>
