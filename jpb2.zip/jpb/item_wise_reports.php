<!DOCTYPE html>
<html>
<?php include 'connection.php' ;?>

<head>
    
   
    
         	<script src="js/excel1.js"></script>  
			<script src="js/excel2.js"></script>  
			<script src="js/excel3.js"></script>  
			<script src="js/excel4.js"></script> 
			<link rel="stylesheet" href="css/excel1.css" />  
			<link rel="stylesheet" href="css/excel2.css" /> 
			
<script src="js1/select2.full.min.js"></script>
<script src="js1/jquery.inputmask.bundle.min.js"></script>


			
			
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->

	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
	
	
	



	

	
	<style>
	
	input.form-control {
    font-size: 20px !important;
}


	button.btn.btn-default.xls {
    background: brown;
    color: white;
	display: none !important;
}
button.btn.btn-default.csv {
    
}
button.btn.btn-default.txt {
    display: none !important;
}


button.print_button {
    float: right;
    font-size: 15px !important;
    background-color: #e57498;
    color: #fff !important;
    margin-top: -3%;
}

	
	a.btn.btn-primary.m-b-5.m-r-2 {
    float: right;
	margin-top: 1.7%;
	}

td.span3.manufacturer {
    padding: 0.5% 0.2% !important;
}

input.form-control {
    padding: .5% .75% !important;
    height: 35px !important;
}
.table-bordered td, .table-bordered th {
    border: 0px solid #dee2e6!important;
}

th.text-center {
    font-size: 12px !important;
}

th.text-center {
    background-color: green;
    color: #fff;
}

.widget-area-2 {
    margin-top: 3px !important;
}

div#lists {
    height: 225px;
    border: 1px solid #ddd;
    width: 104%;
    overflow: auto;
    padding: 0px !important;
    margin: 1% -2%;
}


table#order {
    width: 100%;
}
thead#order_h {
    border: 1px solid #ddd;
}

td.bor {
    border: 1px solid #ddd;
}

button.btn.btn-primary.btn-lg {
	
    background-color: #dc6c97 !important;
}

.form-group.col-md-2 {
    margin-bottom: 0% !important;
}

input.btn.btn-primary.btn-sm {
    width: 50%;
    margin-top: 18%;
    margin-left: 20%;
}

i.ti-close {
    font-size: 13px;
    font-weight: bold;
}

select#invoice_type {
    height: 30px !important;
    padding: 1px 10px;
}

select#expenses_category {
    height: 35px;
}

select#pay_type {
    height: 35px;
}

table.table tbody td, table.table thead th {
    font-size: 14px;
    border: 1px solid #ddd !important;
}

button.btn.btn-primary.btn-lg {
    margin-top: 5.4%;
    margin-left: 10%;
}

	</style>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			<!-- Page Title -->
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Item Wise Sales</h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
						<li class="breadcrumb-item active">Item Wise Sales</li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
						
							<h3 class="widget-title">Item Wise Sales</h3>
			
							<form method="post"	action="">
								<div class="form-row">
									
									
									
									<div class="form-group col-md-3">
										<label for="dob">From Date</label>
	<input type="text" class="form-control" data-inputmask-alias="datetime" value="" name = "from_date" data-inputmask-inputformat="dd/mm/yyyy" data-mask required>

									</div>
									
										<div class="form-group col-md-3">
										<label for="dob">To Date</label>
	<input type="text" class="form-control" data-inputmask-alias="datetime" value="" name = "to_date" data-inputmask-inputformat="dd/mm/yyyy" data-mask required>

									</div>
									
									

									<div class="form-group col-md-6 mb-3">
										<button type="submit" name="submit" class="btn btn-primary btn-lg">Submit</button>
									</div>
									
								</div>
								
							</form>
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			
			<?php 
			
			if(isset($_POST['submit'])) {
			
			?>
			
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
							<h3 class="widget-title">Item Wise Sales</h3>		
							
							    <div class="two">
   	                    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="  Search with Product name.." title="Type in a name" style="width: 100%;margin: 1% 0%;height:45px;font-size:18px;">
                    </div>
							
						
						
						
							<div class="table-responsive mb-3" id="excel_table">
							    <button class ="print_button" onclick = "printDiv()">Print Report</button>  
								<table id="tableId" class="table table-bordered table-striped" >
									<thead>
										<tr>
											
											<th>S No</th>
											<th>Item Name</th>
											<th>Qty</th>
										
											
											
										</tr>
									</thead>
									<tbody>
									
									<?php
									
								
									$parts = explode('/',$_POST['from_date']);
									$from = $parts[2].'-'.$parts[1].'-'.$parts[0];

									$parts = explode('/',$_POST['to_date']);
									$to = $parts[2].'-'.$parts[1].'-'.$parts[0];


									
									$i=0;
									
								 		 $sql = "SELECT GROUP_CONCAT(item_name) as item_names FROM `i_sale_products` where date between '$from' and '$to' and login_store = '".$_SESSION['login_store']."'  GROUP BY `item_name` ASC ";
									 
									$res = mysqli_query($con,$sql);
									$i = 0;
									$tot =0;
									while($row = mysqli_fetch_assoc($res)){
										$i++;
									 
    $code_array = explode(",",$row['item_names']);
	$code_array = array_unique($code_array);

foreach($code_array as $item_name){
	
	
	
									
									$sql1 = "SELECT sum(qty) as qty  FROM `i_sale_products`  where item_name = '".$item_name."' and date between '".$from."' and '".$to."' and login_store = '".$_SESSION['login_store']."' ";
									$result1 = mysqli_query($con , $sql1);
									$row1 = mysqli_fetch_assoc($result1);

									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $item_name; ?></td>
											<td><?php echo $row1['qty']; ?></td>

											
										</tr>
									<?php }} ?>
									</tbody>
								</table>
								
								
							</div>
							
							<!-- EXCEL -->
							
							
							<!-- PRINT START -->
							
							<div class="table-responsive mb-3"  id="print_table" style="display:none">
								<table id="tableId" class="table table-bordered table-striped">
									<thead>
										<tr>
											
											<th>S No</th>
											<th>Item Name</th>
											<th>Qty</th>
										
											
											
										</tr>
									</thead>
									<tbody>
									
									<?php
									
								
									$parts = explode('/',$_POST['from_date']);
									$from = $parts[2].'-'.$parts[1].'-'.$parts[0];

									$parts = explode('/',$_POST['to_date']);
									$to = $parts[2].'-'.$parts[1].'-'.$parts[0];


									
									$i=0;
									
								 		 $sql = "SELECT GROUP_CONCAT(item_name) as item_names FROM `i_sale_products` where date between '$from' and '$to' and login_store = '".$_SESSION['login_store']."'  GROUP BY `item_name` ASC ";
									 
									$res = mysqli_query($con,$sql);
									$i = 0;
									$tot =0;
									while($row = mysqli_fetch_assoc($res)){
										$i++;
									 
    $code_array = explode(",",$row['item_names']);
	$code_array = array_unique($code_array);

foreach($code_array as $item_name){
	
	
	
									
									$sql1 = "SELECT sum(qty) as qty  FROM `i_sale_products`  where item_name = '".$item_name."' and date between '".$from."' and '".$to."' and login_store = '".$_SESSION['login_store']."'  ";
									$result1 = mysqli_query($con , $sql1);
									$row1 = mysqli_fetch_assoc($result1);

									?>
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $item_name; ?></td>
											<td><?php echo $row1['qty']; ?></td>

											
										</tr>
									<?php }} ?>
									</tbody>
								</table>
								
								
							</div>
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			
			<?php } ?>
			
			
			<!-- /Main Content -->
			
			
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>



<script>





  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd-mm-yyyy', { 'placeholder': 'dd-mm-yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm-dd-yyyy', { 'placeholder': 'mm-dd-yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      locale: {
        format: 'MM-DD-YYYY hh:mm A'
      }
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Timepicker
    $('#timepicker').datetimepicker({
      format: 'LT'
    })
    
    //Bootstrap Duallistbox
    $('.duallistbox').bootstrapDualListbox()

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    $('.my-colorpicker2').on('colorpickerChange', function(event) {
      $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
    });

    $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });

  })
  
  
  
  
function printDiv() {
     var printContents = document.getElementById('print_table').innerHTML;


  var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;

   
}


$('#excel_table').tableExport();  




function myFunction() {
  var input, filter, table, tr, td, i, txtValue, txtValue2;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("tableId");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
	
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1  ) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}



</script>
</body>


</html>
