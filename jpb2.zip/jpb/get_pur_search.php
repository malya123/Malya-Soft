<?php
include "connection.php";

if(isset($_POST['save'])){
$bill_generate =0;
$save = 1;
}
	if(isset($_POST['generate'])){
$bill_generate =1;
$save = 1;
}

$vendor = $_POST['vendor'];
$vendor_id = $_POST['vendor_id'];

$invoice_no = $_POST['invoice_no'];



	if($save==1){
	$product = $_POST['product'];
	$sale_id = $_POST['sale_id'];
	
	foreach($_POST['ids'] as $i){
		unset($parts);
$parts = array();
		foreach($product[$i] as $part){
			$parts[] = $part;
			
		}
		
		
		 $sql_u = "SELECT * from `i_pur_products` WHERE `id` = '".$i."'";
		$res_u = mysqli_query($con,$sql_u);
		$row_u = mysqli_fetch_assoc($res_u);
	 $old_qty = $row_u['qty'];
	 
	 $sql_i = "SELECT p_id,qty from i_products where item_name = '".$row_u['item_name']."' ";
		$result_i= mysqli_query($con,$sql_i);
		$row_i = mysqli_fetch_assoc($result_i);
		$qty = $row_i['qty'];
		$new_qty = $row_i['qty']-$old_qty;
		$p_id = $row_i['p_id'];
		
	    $sqls = "UPDATE `i_products` SET `qty` = '".$new_qty."' WHERE `p_id` = '".$p_id."'";
			mysqli_query($con,$sqls);
			
			
			 $sqls = "UPDATE `i_pur_products` SET `qty` = '".$parts[1]."', 
												  `bill_amount` = '".$parts[2]."', 
												  `pur_rate` = '".$parts[3]."', 
												  `sale_rate` = '".$parts[4]."', 
												  `sale_per` = '".$parts[5]."' WHERE `id` = '".$i."'";
			
	 
			mysqli_query($con,$sqls);
			
			$sql_i = "SELECT p_id,qty from i_products where item_name = '".$parts[0]."' ";
		$result_i= mysqli_query($con,$sql_i);
		$row_i = mysqli_fetch_assoc($result_i);
		
		 $new_qty = $row_i['qty']+$parts[1];	
		 $p_id = $row_i['p_id'];
		
		 $sqls = "UPDATE `i_products` SET `qty` = '".$new_qty."'  WHERE `p_id` = '".$p_id."'";
			mysqli_query($con,$sqls);
			
			echo '<br>';
	}
	
	
	
	$bill_amt = $_POST['bill_amt'];
	$bill_dis = $_POST['bill_dis'];
	$advance = $_POST['advance'];
	$balance = $_POST['balance'];
	$net_amount = $_POST['net_amount'];
	
	$paid_amount = $bill_amt - $bill_dis ; 
	
	$pts = explode('-', $_POST['invoice_date']);
	$invoice_date = $pts[2].'-'.$pts[1].'-'.$pts[0];
	
	$invoice_type = $_POST['invoice_type'];
	
	
	 if($invoice_type == 'CREDIT') {
	

    $sqls = "UPDATE `i_purchase` SET `bill_amt` = '".$bill_amt."', 
								  `bill_dis` = '".$bill_dis."', 
								  `advance` = '".$advance."',
								  `net_amount` = '0',
								  `invoice_date` = '".$invoice_date."', 
								  `balance` = '".$balance."'  WHERE `id` = '".$sale_id."'";
	mysqli_query($con,$sqls);
	
	

}
 
	else  {
	

   $sqls = "UPDATE `i_purchase` SET `bill_amt` = '".$bill_amt."', 
								  `bill_dis` = '".$bill_dis."', 
								  `net_amount` = '".$net_amount."',
								  `invoice_date` = '".$invoice_date."', 
								  `advance` = '0', 
								  `balance` = '0'  WHERE `id` = '".$sale_id."'";
	mysqli_query($con,$sqls);
	
	

	
}
		
}



if($bill_generate == 1){
	
	$url = 'pur_bill_generate.php?pid='.$sale_id;
	redirect($url);
}
  $url = 'pur_report.php?id='.$vendor_id.'&name='.$vendor;
redirect($url);




?>