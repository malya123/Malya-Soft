<?php include'session_check.php';?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

button.btn.btn-primary.mt-3.mb-0 , button.btn.btn-danger.mt-3.mb-0 {
    margin: 0% !important;
}

span.theme-click {
    display: none !important;
}

#sidebar .sidebar-header {
    padding: 0px !important;
    background-color: #fff;
    border-right: 1px solid #ddd;
}

p.f_ses {
    color: #fff;
    text-align: center;
    font-size: 16px;
    text-transform: uppercase;
}

span.blink {
    color: greenyellow;
    font-size: 22px !important;
    border-radius: 10px;
    border: 1px solid;
}

</style>


<nav id="sidebar" class="proclinic-bg">
			<div class="sidebar-header">
				<a href="sale.php"><img src="images/logo.jpg" style="width: 160px;height: auto;margin-left: 20%;"  class="logo" alt="logo"></a>
			</div>
		
			<ul class="list-unstyled components">
			<?php $user = $_SESSION['login_user'];
 $sql="select *  from admin where  username='$user'";
$result= mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
									if($row['type'] =='ADMIN'){?>
				<li>
				
					<a href="addparties.php">
						<span class="ti-layout-menu-v"></span>Add party
					</a>
				</li>
									<?php } ?>
				<li>
					<a href="addproduct.php">
						<span class="ti-layout-menu-v"></span>Add product
					</a>
				</li>
				
				<li>
					<a href="barcode.php">
						<span class="ti-layout-menu-v"></span> Barcode
					</a>
				</li>
				
				<li>
					<a href="viewbarcode.php">
						<span class="ti-layout-menu-v"></span>Viewbarcode
					</a>
				</li>

				
				<li>
					<a href="rate.php">
						<span class="ti-layout-menu-v"></span>rate
					</a>
				</li>
				
					<li>
					<a href="sale3.php">
						<span class="ti-layout-menu-v"></span>sale
				
					</a>
				</li>
			<!--<li>
					<a href="jamalu.php">
						<span class="ti-layout-menu-v"></span>reports
					</a>
				</li>-->
				
				
				
			
				
			
			
			<li>
					<a href="#nav-exp1" data-toggle="collapse" aria-expanded="false">
						<span class="ti-layout-menu-v"></span>report
					</a>
					<ul class="collapse list-unstyled" id="nav-exp1">
						<li>
							<a href="">Barcode report</a>
						</li>
						<li>
							<a href="">sale report</a>
						</li>
						
						<li>
							<a href="">stock report</a>
						</li>
						
					</ul>
				</li>
				
			
				
						
			
				
				
			
					
					
					
				
		
									
									
				
				
			
				
					<li>
					<a href="logout.php">
						<span class="ti-layout-menu-v"></span> Logout
					</a>
				</li>
				
				
				
			</ul>
		
		</nav>