<?php

include "connection.php";

if(isset($_POST['save'])){
$bill_generate =0;
$save = 1;
}

	if(isset($_POST['generate'])){
$bill_generate =1;
$save = 1;
}
	if($save==1){
	$product = $_POST['product'];
	$sale_id = $_POST['sale_id'];
	$bill_amount = 0;
	foreach($_POST['ids'] as $i){
		unset($parts);
$parts = array();
		foreach($product[$i] as $part){
			$parts[] = $part;
			
		}
		
		
		
	   $sql_u = "SELECT * from `i_sale_products` WHERE `id` = '".$i."'";
		$res_u = mysqli_query($con,$sql_u);
		$row_u = mysqli_fetch_assoc($res_u);
	   $old_qty = $row_u['qty'];
	   $sid = $row_u['sid'];

	   $item_name = $row_u['item_name'];
	   
	      $sql_i = "SELECT p_id,qty from i_products where item_name = '".$row_u['item_name']."' ";
		$result_i= mysqli_query($con,$sql_i);
		$row_i = mysqli_fetch_assoc($result_i);
		$qty = $row_i['qty'];
	 	 $new_qty = $row_i['qty']+$old_qty;
		 $p_id = $row_i['p_id'];
		 

	   

	 
		 	  $sqls = "UPDATE `i_products` SET `qty` = '".$new_qty."' WHERE `p_id` = '".$p_id."'";
			mysqli_query($con,$sqls);
			
	  	 $sqls = "UPDATE `i_sale_products` SET 		`qty` = '".$parts[1]."',
													`dis_per` = '".$parts[3]."',
													`dis_amt` = '".$parts[4]."',
													`tax_amt` = '".$parts[6]."',
													`bill_amount` = '".$parts[7]."' WHERE `id` = '".$i."'";
			mysqli_query($con,$sqls);
			
		$sql_i = "SELECT p_id,qty from i_products where item_name = '".$parts[0]."' ";
		$result_i= mysqli_query($con,$sql_i);
		$row_i = mysqli_fetch_assoc($result_i);
		
		  $new_qty = $row_i['qty']-$parts[1];	
			$p_id = $row_i['p_id'];
	 		  $sqls = "UPDATE `i_products` SET `qty` = '".$new_qty."'  WHERE `p_id` = '".$p_id."'";
			mysqli_query($con,$sqls);
			

	   
	   
	
	
			echo '<br>';
	}
	
	
	
	$cgst_amount = $_POST['cgst_amount'];
	$sgst_amount = $_POST['sgst_amount'];
	$bill_amt = $_POST['bill_amt'];
	$bill_dis_per = $_POST['bill_dis_per'];
	$bill_dis_rs = $_POST['bill_dis_rs'];
	$advance = $_POST['advance'];
	$balance = $_POST['balance'];
	$net_amount = $_POST['net_amount'];
	$invoice_type = $_POST['invoice_type'];
	
	$pts = explode('-', $_POST['date']);
	$date = $pts[2].'-'.$pts[1].'-'.$pts[0];
	
	
	$bill_no = $_POST['bill_no'];
	
	
	$sqls = "SELECT * FROM `i_sale` WHERE `id` = '$sale_id'";
	$res = mysqli_query($con,$sqls);
	$row = mysqli_fetch_assoc($res);

	$invoice_type = $_POST['invoice_type'];


	 if($invoice_type == 'CREDIT') {


   $sqls = "UPDATE `i_sale` SET `cgst_amount` = '$cgst_amount', 
							  `sgst_amount` = '$sgst_amount', 
							  `bill_amt` = '$bill_amt', 
							  `bill_dis_per` = '$bill_dis_per',
							  `bill_dis_rs` = '$bill_dis_rs',
							  `advance` = '$advance', 
							  `balance` = '$balance', 
							  `net_amount` = '0', 
							  `invoice_type` = '$invoice_type', 
							  `bill_no` = '$bill_no', 
							  `date` = '$date' WHERE `id` = '$sale_id'";
mysqli_query($con,$sqls);

	 }
	 
	 else {
		 
		 
	 	   $sqls = "UPDATE `i_sale` SET `cgst_amount` = '$cgst_amount', 
							  `sgst_amount` = '$sgst_amount', 
							  `bill_amt` = '$bill_amt', 
							  `bill_dis_per` = '$bill_dis_per',
							  `bill_dis_rs` = '$bill_dis_rs',
							  `advance` = '0', 
							  `balance` = '0', 
							  `net_amount` = '$net_amount', 
							  `invoice_type` = '$invoice_type', 
							  `bill_no` = '$bill_no', 
							  `date` = '$date' WHERE `id` = '$sale_id'";
mysqli_query($con,$sqls);
		 
	 }


}
 if($bill_generate == 1){
	
	$url = 'print_sale_bill.php?id='.$sale_id;
	redirect($url);
}

	$url = 'sale_reports.php';
	redirect($url);

?>