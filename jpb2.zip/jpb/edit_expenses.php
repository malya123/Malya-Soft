<!DOCTYPE html>
<html>
<?php include 'connection.php' ;?>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Basil Organics</title>
	<!-- Fav  Icon Link -->
	<link rel="shortcut icon" type="image/png" href="images/fav.png">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- themify icons CSS -->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Animations CSS -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/red.css" id="style_theme">
	<link rel="stylesheet" href="css/responsive.css">
	<!-- morris charts -->
	<link rel="stylesheet" href="charts/css/morris.css">
	<!-- jvectormap -->
	<link rel="stylesheet" href="css/jquery-jvectormap.css">
	<link rel="stylesheet" href="datatable/dataTables.bootstrap4.min.css">

	<script src="js/modernizr.min.js"></script>
	
	
	
<script src="js1/jquery.min.js"></script>
<script src="js1/select2.full.min.js"></script>
<script src="js1/jquery.inputmask.bundle.min.js"></script>


	
	<style>
	
	a.btn.btn-primary.m-b-5.m-r-2 {
    float: right;
	margin-top: 1.7%;
	}

td.span3.manufacturer {
    padding: 0.5% 0.2% !important;
}

input.form-control {
    padding: .5% .75% !important;
    height: 35px !important;
}
.table-bordered td, .table-bordered th {
    border: 0px solid #dee2e6!important;
}

th.text-center {
    font-size: 12px !important;
}

th.text-center {
    background-color: green;
    color: #fff;
}

.widget-area-2 {
    margin-top: 3px !important;
}

div#lists {
    height: 225px;
    border: 1px solid #ddd;
    width: 104%;
    overflow: auto;
    padding: 0px !important;
    margin: 1% -2%;
}


table#order {
    width: 100%;
}
thead#order_h {
    border: 1px solid #ddd;
}

td.bor {
    border: 1px solid #ddd;
}

button.btn.btn-primary.btn-lg {
	
    background-color: #dc6c97 !important;
}

.form-group.col-md-2 {
    margin-bottom: 0% !important;
}

input.btn.btn-primary.btn-sm {
    width: 50%;
    margin-top: 18%;
    margin-left: 20%;
}

i.ti-close {
    font-size: 13px;
    font-weight: bold;
}

select#invoice_type {
    height: 30px !important;
    padding: 1px 10px;
}

select#expenses_category {
    height: 35px;
}

select#pay_type {
    height: 35px;
}

table.table tbody td, table.table thead th {
    font-size: 14px;
    border: 1px solid #ddd !important;
}

	</style>
</head>

<body>
	<!-- Pre Loader -->
	<div class="loading">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
	</div>
	<!--/Pre Loader -->
	<!-- Color Changer -->
	<div class="theme-settings" id="switcher">
		<span class="theme-click">
			<span class="ti-settings"></span>
		</span>
		<span class="theme-color theme-default theme-active" data-color="green"></span>
		<span class="theme-color theme-blue" data-color="blue"></span>
		<span class="theme-color theme-red" data-color="red"></span>
		<span class="theme-color theme-violet" data-color="violet"></span>
		<span class="theme-color theme-yellow" data-color="yellow"></span>
	</div>
	<!-- /Color Changer -->
	<div class="wrapper">
		<!-- Sidebar -->
		<?php include 'nav.php'; ?>
		<!-- /Sidebar -->
		<!-- Page Content -->
		<div id="content">
			<!-- Top Navigation -->

			<!-- /Top Navigation -->
			<!-- Breadcrumb -->
			<!-- Page Title -->
			<div class="row no-margin-padding">
				<div class="col-md-6">
					<h3 class="block-title">Edit Expenses </h3>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb">						
						<li class="breadcrumb-item">
							<a href="dashboard.php">
								<span class="ti-home"></span>
							</a>
                        </li>
                        <li class="breadcrumb-item">Expenses</li>
						<li class="breadcrumb-item active">Edit Expenses </li>
					</ol>
				</div>
			</div>
			<!-- /Page Title -->

			<!-- /Breadcrumb -->
			<!-- Main Content -->
			<div class="container-fluid">

				<div class="row">
					<!-- Widget Item -->
					<div class="col-md-12">
						<div class="widget-area-2 proclinic-box-shadow">
						
							<h3 class="widget-title">Edit Expenses </h3>
			
							<form method="post" action="update_expenses.php">
								<div class="form-row">
									
								<?php 
							$sql = "Select * from `i_expenses` where id = '".$_GET['id']."' ";
							$result = mysqli_query($con , $sql);
							$row = mysqli_fetch_assoc($result);

								?>								
									
									<div class="form-group col-md-4">
										<label for="dob">Invoice Date</label>
	<input type="text" class="form-control" data-inputmask-alias="datetime" value="<?php echo decode_date($row['date']); ?>" name = "date" data-inputmask-inputformat="dd/mm/yyyy" data-mask>

									</div>
									
									
									<div class="form-group col-md-4">
										<label for="patient-name">Person Name</label>
										<input type="text" class="form-control" name="person_name" id="person_name" value="<?php echo $row['person_name']; ?>">
										<input type="hidden" class="form-control" name="update_id" id="update_id" value="<?php echo $_GET['id']; ?>">
									</div>
									
									
									<div class="form-group col-md-4">
										<label for="patient-name">Expenses Name</label>
										<input type="text" class="form-control" name="exp_name" id="exp_name" value="<?php echo $row['exp_name']; ?>">
									</div>
									
								<div class="form-group col-md-4">
										<label for="patient-name">Expenses Category</label>
						<select class="form-control" name="expenses_category" id="expenses_category" required="">
						<option value="0" selected=""></option>
						<option value="To Salaries Paid" <?php if($row['expenses_category'] == 'To Salaries Paid') echo 'Selected' ; else echo ''; ?>>To Salaries Paid</option>
						<option value="To Electricity Charges" <?php if($row['expenses_category'] == 'To Electricity Charges') echo 'Selected' ; else echo ''; ?>>To Electricity Charges</option>
						<option value="To Rent" <?php if($row['expenses_category'] == 'To Rent') echo 'Selected' ; else echo ''; ?>>To Rent</option>
						<option value="To Transport Charges" <?php if($row['expenses_category'] == 'To Transport Charges') echo 'Selected' ; else echo ''; ?>>To Transport Charges</option>
						<option value="To Personal Use" <?php if($row['expenses_category'] == 'To Personal Use') echo 'Selected' ; else echo ''; ?>>To Personal Use</option>
						<option value="To Labour Charges" <?php if($row['expenses_category'] == 'To Labour Charges') echo 'Selected' ; else echo ''; ?>>To Labour Charges</option>
						<option value="To Misc. and General Expenses" <?php if($row['expenses_category'] == 'To Misc. and General Expenses') echo 'Selected' ; else echo ''; ?>>To Misc. & General Expenses</option>
						<option value="To Printing and Stationary" <?php if($row['expenses_category'] == 'To Printing and Stationary') echo 'Selected' ; else echo ''; ?>>To Printing & Stationary</option>
						<option value="To Professional Charges" <?php if($row['expenses_category'] == 'To Professional Charges') echo 'Selected' ; else echo ''; ?>>To Professional Charges</option>
						<option value="To Telephone Charges" <?php if($row['expenses_category'] == 'To Telephone Charges') echo 'Selected' ; else echo ''; ?>>To Telephone Charges</option>
						<option value="To Duties and Tax" <?php if($row['expenses_category'] == 'To Duties and Tax') echo 'Selected' ; else echo ''; ?>>To Duties & Tax</option>
						<option value="To Bank Charges" <?php if($row['expenses_category'] == 'To Bank Charges') echo 'Selected' ; else echo ''; ?>>To Bank Charges</option>
						<option value="To Bank Interest-CC a/c" <?php if($row['expenses_category'] == 'To Bank Interest-CC a/c') echo 'Selected' ; else echo ''; ?>>To Bank Interest-CC a/c</option>
						<option value="To Depreciation" <?php if($row['expenses_category'] == 'To Depreciation') echo 'Selected' ; else echo ''; ?>>To Depreciation</option>
						<option value="Other Expenses" <?php if($row['expenses_category'] == 'Other Expenses') echo 'Selected' ; else echo ''; ?>>Other Expenses</option>

						</select>
									</div>
									
								<div class="form-group col-md-4">
										<label for="patient-name">Amount</label>
										<input type="text" class="form-control" name="amount" id="amount"value="<?php echo $row['amount']; ?>">
									</div>
									
								<div class="form-group col-md-4">
										<label for="patient-name">Payment Type</label>
									<select class="form-control" name="pay_type" id="pay_type" required="" >
									<option value="Cash" <?php if($row['pay_type'] == 'Cash') echo 'Selected' ; else echo ''; ?>>Cash</option>
									<option value="Bank" <?php if($row['pay_type'] == 'Bank') echo 'Selected' ; else echo ''; ?>>Bank</option>
									</select>
								</div>
									
								
									<div class="form-group col-md-12">
										<label for="patient-name">Remarks</label>
										<textarea type="text" class="form-control" name="remarks" id="remarks"><?php echo $row['remarks']; ?></textarea>
									</div>
									

									<div class="form-group col-md-6 mb-3">
										<button type="submit" name="submit" class="btn btn-primary btn-lg">Update</button>
									</div>
									
								</div>
								
							</form>
							
						</div>
					</div>
					<!-- /Widget Item -->
				</div>
			</div>
			
			
			<!-- /Main Content -->
			
			
		</div>
		<!-- /Page Content -->
	</div>
	<!-- Back to Top -->
	<a id="back-to-top" href="#" class="back-to-top">
		<span class="ti-angle-up"></span>
	</a>
	<!-- /Back to Top -->
	<!-- Jquery Library-->
	<!-- <script src="js/jquery-3.2.1.min.js"></script> -->
	<!-- Popper Library-->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap Library-->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Datatable  -->
	<script src="datatable/jquery.dataTables.min.js"></script>
	<script src="datatable/dataTables.bootstrap4.min.js"></script>
    
	<!-- Custom Script-->
	<script src="js/custom.js"></script>



<script>





  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd-mm-yyyy', { 'placeholder': 'dd-mm-yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm-dd-yyyy', { 'placeholder': 'mm-dd-yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      locale: {
        format: 'MM-DD-YYYY hh:mm A'
      }
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Timepicker
    $('#timepicker').datetimepicker({
      format: 'LT'
    })
    
    //Bootstrap Duallistbox
    $('.duallistbox').bootstrapDualListbox()

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    $('.my-colorpicker2').on('colorpickerChange', function(event) {
      $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
    });

    $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });

  })
</script>
</body>


</html>
