<?php

	include "connection.php";

	$item_name = $_GET['item_name'];

 
 	$sql = "Delete FROM items where item_name = '$item_name'";
	$result= mysqli_query($con,$sql);

	$sql = "Delete FROM i_products where item_name = '$item_name'";
	$result= mysqli_query($con,$sql);
	
	$url ="price_list.php";
	redirect($url);
?>